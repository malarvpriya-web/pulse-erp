import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../../crm/pages/Leads.css';

const AttendanceDashboard = () => {
  const [summary, setSummary] = useState(null);
  const [records, setRecords] = useState([]);
  const [showMarkForm, setShowMarkForm] = useState(false);
  const [formData, setFormData] = useState({
    attendance_date: new Date().toISOString().split('T')[0],
    check_in_time: '',
    check_out_time: '',
    status: 'present',
    remarks: ''
  });

  const currentUser = JSON.parse(localStorage.getItem('user') || '{}');

  useEffect(() => {
    fetchSummary();
    fetchRecords();
  }, []);

  const fetchSummary = async () => {
    try {
      const token = localStorage.getItem('token');
      const month = new Date().getMonth() + 1;
      const year = new Date().getFullYear();
      const res = await axios.get(`http://localhost:5000/api/attendance/summary/${currentUser.id}?month=${month}&year=${year}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setSummary(res.data);
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const fetchRecords = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await axios.get(`http://localhost:5000/api/attendance/employee/${currentUser.id}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setRecords(res.data);
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const handleMarkAttendance = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token');
      await axios.post('http://localhost:5000/api/attendance/mark',
        { ...formData, employee_id: currentUser.id },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      alert('Attendance marked successfully');
      setShowMarkForm(false);
      fetchSummary();
      fetchRecords();
    } catch (error) {
      alert('Error marking attendance');
    }
  };

  const getStatusColor = (status) => {
    const colors = {
      present: '#dcfce7',
      absent: '#fee2e2',
      half_day: '#fef3c7',
      wfh: '#dbeafe',
      on_leave: '#e0e7ff'
    };
    return colors[status] || '#f3f4f6';
  };

  return (
    <div className="leads-page">
      <div className="leads-header">
        <h1>My Attendance</h1>
        <button className="primary-btn" onClick={() => setShowMarkForm(true)}>Mark Attendance</button>
      </div>

      {summary && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '20px', marginBottom: '25px' }}>
          <div style={{ background: 'white', padding: '20px', borderRadius: '12px', border: '1px solid #e5e7eb' }}>
            <h3 style={{ fontSize: '18px', color: '#6b7280', margin: '0 0 10px 0' }}>Present Days</h3>
            <p style={{ fontSize: '32px', fontWeight: '700', color: '#0284c7', margin: 0 }}>{summary.present_days || 0}</p>
          </div>
          <div style={{ background: 'white', padding: '20px', borderRadius: '12px', border: '1px solid #e5e7eb' }}>
            <h3 style={{ fontSize: '18px', color: '#6b7280', margin: '0 0 10px 0' }}>Absent Days</h3>
            <p style={{ fontSize: '32px', fontWeight: '700', color: '#dc2626', margin: 0 }}>{summary.absent_days || 0}</p>
          </div>
          <div style={{ background: 'white', padding: '20px', borderRadius: '12px', border: '1px solid #e5e7eb' }}>
            <h3 style={{ fontSize: '18px', color: '#6b7280', margin: '0 0 10px 0' }}>Late Arrivals</h3>
            <p style={{ fontSize: '32px', fontWeight: '700', color: '#f59e0b', margin: 0 }}>{summary.late_arrivals || 0}</p>
          </div>
          <div style={{ background: 'white', padding: '20px', borderRadius: '12px', border: '1px solid #e5e7eb' }}>
            <h3 style={{ fontSize: '18px', color: '#6b7280', margin: '0 0 10px 0' }}>Total Hours</h3>
            <p style={{ fontSize: '32px', fontWeight: '700', color: '#059669', margin: 0 }}>{parseFloat(summary.total_hours_worked || 0).toFixed(1)}h</p>
          </div>
        </div>
      )}

      {showMarkForm && (
        <div className="form-modal">
          <div className="form-card">
            <h2>Mark Attendance</h2>
            <form onSubmit={handleMarkAttendance}>
              <div className="form-group">
                <label>Date</label>
                <input
                  type="date"
                  value={formData.attendance_date}
                  onChange={(e) => setFormData({ ...formData, attendance_date: e.target.value })}
                  required
                />
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Check In Time</label>
                  <input
                    type="time"
                    value={formData.check_in_time}
                    onChange={(e) => setFormData({ ...formData, check_in_time: e.target.value })}
                  />
                </div>
                <div className="form-group">
                  <label>Check Out Time</label>
                  <input
                    type="time"
                    value={formData.check_out_time}
                    onChange={(e) => setFormData({ ...formData, check_out_time: e.target.value })}
                  />
                </div>
              </div>

              <div className="form-group">
                <label>Status</label>
                <select
                  value={formData.status}
                  onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                >
                  <option value="present">Present</option>
                  <option value="wfh">Work From Home</option>
                  <option value="half_day">Half Day</option>
                </select>
              </div>

              <div className="form-group">
                <label>Remarks</label>
                <textarea
                  value={formData.remarks}
                  onChange={(e) => setFormData({ ...formData, remarks: e.target.value })}
                  rows="2"
                />
              </div>

              <div className="form-actions">
                <button type="button" className="cancel-btn" onClick={() => setShowMarkForm(false)}>Cancel</button>
                <button type="submit" className="submit-btn">Mark Attendance</button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="leads-table-container">
        <table className="leads-table">
          <thead>
            <tr>
              <th>Date</th>
              <th>Check In</th>
              <th>Check Out</th>
              <th>Total Hours</th>
              <th>Status</th>
              <th>Late Minutes</th>
            </tr>
          </thead>
          <tbody>
            {records.map(record => (
              <tr key={record.id}>
                <td>{new Date(record.attendance_date).toLocaleDateString()}</td>
                <td>{record.check_in_time || '-'}</td>
                <td>{record.check_out_time || '-'}</td>
                <td>{record.total_hours || '-'}h</td>
                <td>
                  <span className="badge" style={{ background: getStatusColor(record.status) }}>
                    {record.status.replace('_', ' ')}
                  </span>
                </td>
                <td>{record.late_minutes || 0} min</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AttendanceDashboard;
