import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './Leads.css';

const Leads = () => {
  const [leads, setLeads] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [employees, setEmployees] = useState([]);
  const [formData, setFormData] = useState({
    lead_source: 'website',
    company_name: '',
    contact_person: '',
    email: '',
    phone: '',
    industry: '',
    location: '',
    assigned_to: '',
    status: 'new',
    notes: ''
  });

  useEffect(() => {
    fetchLeads();
    fetchEmployees();
  }, []);

  const fetchLeads = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await axios.get('http://localhost:5000/api/crm/leads', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setLeads(res.data);
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const fetchEmployees = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await axios.get('http://localhost:5000/api/employees', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setEmployees(res.data);
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token');
      await axios.post('http://localhost:5000/api/crm/leads', formData, {
        headers: { Authorization: `Bearer ${token}` }
      });
      alert('Lead created successfully');
      setShowForm(false);
      fetchLeads();
      setFormData({
        lead_source: 'website',
        company_name: '',
        contact_person: '',
        email: '',
        phone: '',
        industry: '',
        location: '',
        assigned_to: '',
        status: 'new',
        notes: ''
      });
    } catch (error) {
      alert('Error creating lead');
    }
  };

  const getStatusColor = (status) => {
    const colors = {
      new: '#dbeafe',
      contacted: '#fef3c7',
      qualified: '#dcfce7',
      unqualified: '#fee2e2',
      converted: '#d1fae5'
    };
    return colors[status] || '#f3f4f6';
  };

  const getSourceColor = (source) => {
    const colors = {
      website: '#dbeafe',
      linkedin: '#e0e7ff',
      referral: '#fce7f3',
      campaign: '#fef3c7',
      manual: '#f3f4f6'
    };
    return colors[source] || '#f3f4f6';
  };

  return (
    <div className="leads-page">
      <div className="leads-header">
        <h1>Leads</h1>
        <button className="primary-btn" onClick={() => setShowForm(true)}>+ New Lead</button>
      </div>

      {showForm && (
        <div className="form-modal">
          <div className="form-card">
            <h2>Create New Lead</h2>
            <form onSubmit={handleSubmit}>
              <div className="form-row">
                <div className="form-group">
                  <label>Company Name *</label>
                  <input
                    type="text"
                    value={formData.company_name}
                    onChange={(e) => setFormData({ ...formData, company_name: e.target.value })}
                    required
                  />
                </div>
                <div className="form-group">
                  <label>Contact Person *</label>
                  <input
                    type="text"
                    value={formData.contact_person}
                    onChange={(e) => setFormData({ ...formData, contact_person: e.target.value })}
                    required
                  />
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Email</label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  />
                </div>
                <div className="form-group">
                  <label>Phone</label>
                  <input
                    type="text"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  />
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Lead Source</label>
                  <select
                    value={formData.lead_source}
                    onChange={(e) => setFormData({ ...formData, lead_source: e.target.value })}
                  >
                    <option value="website">Website</option>
                    <option value="linkedin">LinkedIn</option>
                    <option value="referral">Referral</option>
                    <option value="campaign">Campaign</option>
                    <option value="manual">Manual</option>
                  </select>
                </div>
                <div className="form-group">
                  <label>Industry</label>
                  <input
                    type="text"
                    value={formData.industry}
                    onChange={(e) => setFormData({ ...formData, industry: e.target.value })}
                  />
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Location</label>
                  <input
                    type="text"
                    value={formData.location}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                  />
                </div>
                <div className="form-group">
                  <label>Assign To</label>
                  <select
                    value={formData.assigned_to}
                    onChange={(e) => setFormData({ ...formData, assigned_to: e.target.value })}
                  >
                    <option value="">Select Employee</option>
                    {employees.map(e => (
                      <option key={e.id} value={e.id}>{e.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="form-group">
                <label>Notes</label>
                <textarea
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  rows="3"
                />
              </div>

              <div className="form-actions">
                <button type="button" className="cancel-btn" onClick={() => setShowForm(false)}>Cancel</button>
                <button type="submit" className="submit-btn">Create Lead</button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="leads-table-container">
        <table className="leads-table">
          <thead>
            <tr>
              <th>Company</th>
              <th>Contact Person</th>
              <th>Email</th>
              <th>Phone</th>
              <th>Source</th>
              <th>Industry</th>
              <th>Assigned To</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {leads.map(lead => (
              <tr key={lead.id}>
                <td><strong>{lead.company_name}</strong></td>
                <td>{lead.contact_person}</td>
                <td>{lead.email || '-'}</td>
                <td>{lead.phone || '-'}</td>
                <td>
                  <span className="badge" style={{ background: getSourceColor(lead.lead_source) }}>
                    {lead.lead_source}
                  </span>
                </td>
                <td>{lead.industry || '-'}</td>
                <td>{lead.assigned_to_name || 'Unassigned'}</td>
                <td>
                  <span className="badge" style={{ background: getStatusColor(lead.status) }}>
                    {lead.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Leads;
