import React from 'react';

const SalesDashboard = () => {
  return <div>Sales Dashboard Page</div>;
};

export default SalesDashboard;