import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './OpportunitiesKanban.css';

const OpportunitiesKanban = () => {
  const [board, setBoard] = useState({ qualification: [], proposal: [], negotiation: [], won: [], lost: [] });
  const [showForm, setShowForm] = useState(false);
  const [leads, setLeads] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [formData, setFormData] = useState({
    lead_id: '',
    opportunity_name: '',
    expected_value: '',
    probability_percentage: '',
    expected_closing_date: '',
    stage: 'qualification',
    assigned_to: ''
  });

  useEffect(() => {
    fetchBoard();
    fetchLeads();
    fetchEmployees();
  }, []);

  const fetchBoard = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await axios.get('http://localhost:5000/api/crm/opportunities/kanban', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setBoard(res.data);
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const fetchLeads = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await axios.get('http://localhost:5000/api/crm/leads?status=qualified', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setLeads(res.data);
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const fetchEmployees = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await axios.get('http://localhost:5000/api/employees', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setEmployees(res.data);
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token');
      await axios.post('http://localhost:5000/api/crm/opportunities', formData, {
        headers: { Authorization: `Bearer ${token}` }
      });
      alert('Opportunity created successfully');
      setShowForm(false);
      fetchBoard();
      setFormData({
        lead_id: '',
        opportunity_name: '',
        expected_value: '',
        probability_percentage: '',
        expected_closing_date: '',
        stage: 'qualification',
        assigned_to: ''
      });
    } catch (error) {
      alert('Error creating opportunity');
    }
  };

  const updateStage = async (oppId, newStage) => {
    try {
      const token = localStorage.getItem('token');
      await axios.put(`http://localhost:5000/api/crm/opportunities/${oppId}`,
        { stage: newStage },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      fetchBoard();
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const columns = [
    { key: 'qualification', title: 'Qualification', color: '#dbeafe' },
    { key: 'proposal', title: 'Proposal', color: '#fef3c7' },
    { key: 'negotiation', title: 'Negotiation', color: '#fed7aa' },
    { key: 'won', title: 'Won', color: '#dcfce7' },
    { key: 'lost', title: 'Lost', color: '#fee2e2' }
  ];

  return (
    <div className="opportunities-page">
      <div className="opportunities-header">
        <h1>Sales Pipeline</h1>
        <button className="primary-btn" onClick={() => setShowForm(true)}>+ New Opportunity</button>
      </div>

      {showForm && (
        <div className="form-modal">
          <div className="form-card">
            <h2>Create Opportunity</h2>
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label>Lead *</label>
                <select
                  value={formData.lead_id}
                  onChange={(e) => setFormData({ ...formData, lead_id: e.target.value })}
                  required
                >
                  <option value="">Select Lead</option>
                  {leads.map(l => (
                    <option key={l.id} value={l.id}>{l.company_name} - {l.contact_person}</option>
                  ))}
                </select>
              </div>

              <div className="form-group">
                <label>Opportunity Name *</label>
                <input
                  type="text"
                  value={formData.opportunity_name}
                  onChange={(e) => setFormData({ ...formData, opportunity_name: e.target.value })}
                  required
                />
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Expected Value *</label>
                  <input
                    type="number"
                    value={formData.expected_value}
                    onChange={(e) => setFormData({ ...formData, expected_value: e.target.value })}
                    required
                  />
                </div>
                <div className="form-group">
                  <label>Probability %</label>
                  <input
                    type="number"
                    min="0"
                    max="100"
                    value={formData.probability_percentage}
                    onChange={(e) => setFormData({ ...formData, probability_percentage: e.target.value })}
                  />
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Expected Closing Date</label>
                  <input
                    type="date"
                    value={formData.expected_closing_date}
                    onChange={(e) => setFormData({ ...formData, expected_closing_date: e.target.value })}
                  />
                </div>
                <div className="form-group">
                  <label>Assign To</label>
                  <select
                    value={formData.assigned_to}
                    onChange={(e) => setFormData({ ...formData, assigned_to: e.target.value })}
                  >
                    <option value="">Select Employee</option>
                    {employees.map(e => (
                      <option key={e.id} value={e.id}>{e.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="form-actions">
                <button type="button" className="cancel-btn" onClick={() => setShowForm(false)}>Cancel</button>
                <button type="submit" className="submit-btn">Create Opportunity</button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="kanban-board">
        {columns.map(column => (
          <div key={column.key} className="kanban-column">
            <div className="column-header" style={{ background: column.color }}>
              <h3>{column.title}</h3>
              <span className="count">{board[column.key]?.length || 0}</span>
            </div>
            <div className="column-content">
              {board[column.key]?.map(opp => (
                <div key={opp.id} className="opp-card">
                  <h4>{opp.opportunity_name}</h4>
                  <p className="company">{opp.company_name}</p>
                  <p className="value">₹{parseFloat(opp.expected_value).toLocaleString()}</p>
                  {opp.probability_percentage && (
                    <p className="probability">{opp.probability_percentage}% probability</p>
                  )}
                  {opp.expected_closing_date && (
                    <p className="date">Close: {new Date(opp.expected_closing_date).toLocaleDateString()}</p>
                  )}
                  <p className="assignee">{opp.assigned_to_name || 'Unassigned'}</p>
                  <select
                    value={opp.stage}
                    onChange={(e) => updateStage(opp.id, e.target.value)}
                    className="stage-select"
                  >
                    <option value="qualification">Qualification</option>
                    <option value="proposal">Proposal</option>
                    <option value="negotiation">Negotiation</option>
                    <option value="won">Won</option>
                    <option value="lost">Lost</option>
                  </select>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default OpportunitiesKanban;
