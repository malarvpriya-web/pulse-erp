import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './KanbanBoard.css';

const KanbanBoard = () => {
  const [projects, setProjects] = useState([]);
  const [selectedProject, setSelectedProject] = useState('');
  const [board, setBoard] = useState({ todo: [], in_progress: [], review: [], done: [] });
  const [showTaskForm, setShowTaskForm] = useState(false);
  const [employees, setEmployees] = useState([]);
  const [formData, setFormData] = useState({
    task_title: '',
    task_description: '',
    assigned_to: '',
    priority: 'medium',
    status: 'todo',
    due_date: '',
    estimated_hours: ''
  });

  useEffect(() => {
    fetchProjects();
    fetchEmployees();
  }, []);

  useEffect(() => {
    if (selectedProject) {
      fetchKanbanBoard();
    }
  }, [selectedProject]);

  const fetchProjects = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await axios.get('http://localhost:5000/api/projects/projects?status=active', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setProjects(res.data);
      if (res.data.length > 0) {
        setSelectedProject(res.data[0].id);
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const fetchEmployees = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await axios.get('http://localhost:5000/api/employees', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setEmployees(res.data);
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const fetchKanbanBoard = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await axios.get(`http://localhost:5000/api/projects/tasks/kanban/${selectedProject}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setBoard(res.data);
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token');
      await axios.post('http://localhost:5000/api/projects/tasks', 
        { ...formData, project_id: selectedProject },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      alert('Task created successfully');
      setShowTaskForm(false);
      fetchKanbanBoard();
      setFormData({
        task_title: '',
        task_description: '',
        assigned_to: '',
        priority: 'medium',
        status: 'todo',
        due_date: '',
        estimated_hours: ''
      });
    } catch (error) {
      alert('Error creating task');
    }
  };

  const updateTaskStatus = async (taskId, newStatus) => {
    try {
      const token = localStorage.getItem('token');
      await axios.put(`http://localhost:5000/api/projects/tasks/${taskId}`,
        { status: newStatus },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      fetchKanbanBoard();
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const getPriorityColor = (priority) => {
    const colors = {
      low: '#dbeafe',
      medium: '#fef3c7',
      high: '#fed7aa',
      critical: '#fee2e2'
    };
    return colors[priority] || '#f3f4f6';
  };

  const columns = [
    { key: 'todo', title: 'To Do', color: '#f3f4f6' },
    { key: 'in_progress', title: 'In Progress', color: '#dbeafe' },
    { key: 'review', title: 'Review', color: '#fef3c7' },
    { key: 'done', title: 'Done', color: '#dcfce7' }
  ];

  return (
    <div className="kanban-page">
      <div className="kanban-header">
        <h1>Task Board</h1>
        <div className="header-actions">
          <select
            value={selectedProject}
            onChange={(e) => setSelectedProject(e.target.value)}
            className="project-select"
          >
            {projects.map(p => (
              <option key={p.id} value={p.id}>{p.project_name}</option>
            ))}
          </select>
          <button className="primary-btn" onClick={() => setShowTaskForm(true)}>+ New Task</button>
        </div>
      </div>

      {showTaskForm && (
        <div className="form-modal">
          <div className="form-card">
            <h2>Create New Task</h2>
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label>Task Title *</label>
                <input
                  type="text"
                  value={formData.task_title}
                  onChange={(e) => setFormData({ ...formData, task_title: e.target.value })}
                  required
                />
              </div>

              <div className="form-group">
                <label>Description</label>
                <textarea
                  value={formData.task_description}
                  onChange={(e) => setFormData({ ...formData, task_description: e.target.value })}
                  rows="3"
                />
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Assigned To</label>
                  <select
                    value={formData.assigned_to}
                    onChange={(e) => setFormData({ ...formData, assigned_to: e.target.value })}
                  >
                    <option value="">Select Employee</option>
                    {employees.map(e => (
                      <option key={e.id} value={e.id}>{e.name}</option>
                    ))}
                  </select>
                </div>
                <div className="form-group">
                  <label>Priority</label>
                  <select
                    value={formData.priority}
                    onChange={(e) => setFormData({ ...formData, priority: e.target.value })}
                  >
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                    <option value="critical">Critical</option>
                  </select>
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Due Date</label>
                  <input
                    type="date"
                    value={formData.due_date}
                    onChange={(e) => setFormData({ ...formData, due_date: e.target.value })}
                  />
                </div>
                <div className="form-group">
                  <label>Estimated Hours</label>
                  <input
                    type="number"
                    value={formData.estimated_hours}
                    onChange={(e) => setFormData({ ...formData, estimated_hours: e.target.value })}
                  />
                </div>
              </div>

              <div className="form-actions">
                <button type="button" className="cancel-btn" onClick={() => setShowTaskForm(false)}>Cancel</button>
                <button type="submit" className="submit-btn">Create Task</button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="kanban-board">
        {columns.map(column => (
          <div key={column.key} className="kanban-column">
            <div className="column-header" style={{ background: column.color }}>
              <h3>{column.title}</h3>
              <span className="task-count">{board[column.key]?.length || 0}</span>
            </div>
            <div className="column-content">
              {board[column.key]?.map(task => (
                <div key={task.id} className="task-card">
                  <div className="task-header">
                    <span className="priority-badge" style={{ background: getPriorityColor(task.priority) }}>
                      {task.priority}
                    </span>
                  </div>
                  <h4>{task.task_title}</h4>
                  {task.task_description && <p className="task-desc">{task.task_description}</p>}
                  <div className="task-footer">
                    <span className="assignee">{task.assigned_to_name || 'Unassigned'}</span>
                    {task.due_date && <span className="due-date">Due: {new Date(task.due_date).toLocaleDateString()}</span>}
                  </div>
                  <select
                    value={task.status}
                    onChange={(e) => updateTaskStatus(task.id, e.target.value)}
                    className="status-select"
                  >
                    <option value="todo">To Do</option>
                    <option value="in_progress">In Progress</option>
                    <option value="review">Review</option>
                    <option value="done">Done</option>
                  </select>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default KanbanBoard;
