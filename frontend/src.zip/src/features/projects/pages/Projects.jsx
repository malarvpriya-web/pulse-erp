import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './Projects.css';

const Projects = () => {
  const [projects, setProjects] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    project_code: '',
    project_name: '',
    customer_id: '',
    start_date: '',
    end_date: '',
    project_manager_id: '',
    status: 'planning',
    budget_amount: '',
    description: ''
  });
  const [customers, setCustomers] = useState([]);
  const [employees, setEmployees] = useState([]);

  useEffect(() => {
    fetchProjects();
    fetchCustomers();
    fetchEmployees();
  }, []);

  const fetchProjects = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await axios.get('http://localhost:5000/api/projects/projects', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setProjects(res.data);
    } catch (error) {
      console.error('Error fetching projects:', error);
    }
  };

  const fetchCustomers = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await axios.get('http://localhost:5000/api/finance/parties?type=customer', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setCustomers(res.data);
    } catch (error) {
      console.error('Error fetching customers:', error);
    }
  };

  const fetchEmployees = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await axios.get('http://localhost:5000/api/employees', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setEmployees(res.data);
    } catch (error) {
      console.error('Error fetching employees:', error);
    }
  };

  const handleNewProject = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await axios.get('http://localhost:5000/api/projects/projects/next-code', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setFormData({ ...formData, project_code: res.data.code });
      setShowForm(true);
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token');
      await axios.post('http://localhost:5000/api/projects/projects', formData, {
        headers: { Authorization: `Bearer ${token}` }
      });
      alert('Project created successfully');
      setShowForm(false);
      fetchProjects();
      setFormData({
        project_code: '',
        project_name: '',
        customer_id: '',
        start_date: '',
        end_date: '',
        project_manager_id: '',
        status: 'planning',
        budget_amount: '',
        description: ''
      });
    } catch (error) {
      alert('Error creating project');
    }
  };

  const getStatusColor = (status) => {
    const colors = {
      planning: '#fef3c7',
      active: '#dcfce7',
      on_hold: '#fed7aa',
      completed: '#dbeafe',
      cancelled: '#fee2e2'
    };
    return colors[status] || '#f3f4f6';
  };

  const getProgressPercentage = (total, completed) => {
    if (!total) return 0;
    return Math.round((completed / total) * 100);
  };

  return (
    <div className="projects-page">
      <div className="projects-header">
        <h1>Projects</h1>
        <button className="primary-btn" onClick={handleNewProject}>+ New Project</button>
      </div>

      {showForm && (
        <div className="form-modal">
          <div className="form-card">
            <h2>Create New Project</h2>
            <form onSubmit={handleSubmit}>
              <div className="form-row">
                <div className="form-group">
                  <label>Project Code</label>
                  <input type="text" value={formData.project_code} readOnly />
                </div>
                <div className="form-group">
                  <label>Project Name *</label>
                  <input
                    type="text"
                    value={formData.project_name}
                    onChange={(e) => setFormData({ ...formData, project_name: e.target.value })}
                    required
                  />
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Customer</label>
                  <select
                    value={formData.customer_id}
                    onChange={(e) => setFormData({ ...formData, customer_id: e.target.value })}
                  >
                    <option value="">Select Customer</option>
                    {customers.map(c => (
                      <option key={c.id} value={c.id}>{c.name}</option>
                    ))}
                  </select>
                </div>
                <div className="form-group">
                  <label>Project Manager</label>
                  <select
                    value={formData.project_manager_id}
                    onChange={(e) => setFormData({ ...formData, project_manager_id: e.target.value })}
                  >
                    <option value="">Select Manager</option>
                    {employees.map(e => (
                      <option key={e.id} value={e.id}>{e.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Start Date *</label>
                  <input
                    type="date"
                    value={formData.start_date}
                    onChange={(e) => setFormData({ ...formData, start_date: e.target.value })}
                    required
                  />
                </div>
                <div className="form-group">
                  <label>End Date</label>
                  <input
                    type="date"
                    value={formData.end_date}
                    onChange={(e) => setFormData({ ...formData, end_date: e.target.value })}
                  />
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Budget Amount</label>
                  <input
                    type="number"
                    value={formData.budget_amount}
                    onChange={(e) => setFormData({ ...formData, budget_amount: e.target.value })}
                  />
                </div>
                <div className="form-group">
                  <label>Status</label>
                  <select
                    value={formData.status}
                    onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                  >
                    <option value="planning">Planning</option>
                    <option value="active">Active</option>
                    <option value="on_hold">On Hold</option>
                    <option value="completed">Completed</option>
                    <option value="cancelled">Cancelled</option>
                  </select>
                </div>
              </div>

              <div className="form-group">
                <label>Description</label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  rows="3"
                />
              </div>

              <div className="form-actions">
                <button type="button" className="cancel-btn" onClick={() => setShowForm(false)}>Cancel</button>
                <button type="submit" className="submit-btn">Create Project</button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="projects-grid">
        {projects.map(project => (
          <div key={project.id} className="project-card">
            <div className="project-header">
              <div>
                <h3>{project.project_name}</h3>
                <p className="project-code">{project.project_code}</p>
              </div>
              <span className="status-badge" style={{ background: getStatusColor(project.status) }}>
                {project.status.replace('_', ' ')}
              </span>
            </div>

            <div className="project-info">
              <p><strong>Customer:</strong> {project.customer_name || 'N/A'}</p>
              <p><strong>Manager:</strong> {project.manager_name || 'N/A'}</p>
              <p><strong>Budget:</strong> ₹{parseFloat(project.budget_amount || 0).toLocaleString()}</p>
            </div>

            <div className="project-progress">
              <div className="progress-header">
                <span>Progress</span>
                <span>{getProgressPercentage(project.total_tasks, project.completed_tasks)}%</span>
              </div>
              <div className="progress-bar">
                <div
                  className="progress-fill"
                  style={{ width: `${getProgressPercentage(project.total_tasks, project.completed_tasks)}%` }}
                />
              </div>
              <p className="task-count">{project.completed_tasks || 0} / {project.total_tasks || 0} tasks completed</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Projects;
