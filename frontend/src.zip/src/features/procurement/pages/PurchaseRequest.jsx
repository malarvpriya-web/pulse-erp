import { useState, useEffect } from 'react';
import api from '@/services/api/client';
import './PurchaseRequest.css';

export default function PurchaseRequest() {
  const [prs, setPRs] = useState([]);
  const [items, setItems] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    request_date: new Date().toISOString().split('T')[0],
    required_date: '',
    notes: '',
    items: [{ item_id: '', item_name: '', quantity: 0, expected_price: 0, required_date: '', remarks: '' }]
  });

  useEffect(() => {
    fetchPRs();
    fetchItems();
  }, []);

  const fetchPRs = async () => {
    try {
      const response = await api.get('/procurement/purchase-requests');
      setPRs(response.data);
    } catch (error) {
      console.error('Error fetching PRs:', error);
    }
  };

  const fetchItems = async () => {
    try {
      const response = await api.get('/inventory/items');
      setItems(response.data);
    } catch (error) {
      console.error('Error fetching items:', error);
    }
  };

  const addItem = () => {
    setFormData({
      ...formData,
      items: [...formData.items, { item_id: '', item_name: '', quantity: 0, expected_price: 0, required_date: '', remarks: '' }]
    });
  };

  const removeItem = (index) => {
    const newItems = formData.items.filter((_, i) => i !== index);
    setFormData({ ...formData, items: newItems });
  };

  const handleItemChange = (index, field, value) => {
    const newItems = [...formData.items];
    newItems[index][field] = value;
    
    if (field === 'item_id') {
      const item = items.find(i => i.id === value);
      if (item) {
        newItems[index].item_name = item.item_name;
      }
    }
    
    setFormData({ ...formData, items: newItems });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await api.post('/procurement/purchase-requests', {
        ...formData,
        requested_by_employee_id: 1 // Replace with actual user ID
      });
      alert('Purchase request created successfully');
      setShowForm(false);
      fetchPRs();
      setFormData({
        request_date: new Date().toISOString().split('T')[0],
        required_date: '',
        notes: '',
        items: [{ item_id: '', item_name: '', quantity: 0, expected_price: 0, required_date: '', remarks: '' }]
      });
    } catch (error) {
      alert('Error creating PR: ' + error.message);
    }
  };

  const handleApprove = async (id) => {
    try {
      await api.put(`/procurement/purchase-requests/${id}/approve`);
      alert('PR approved successfully');
      fetchPRs();
    } catch (error) {
      alert('Error approving PR: ' + error.message);
    }
  };

  return (
    <div className="pr-page">
      <div className="page-header">
        <h1>Purchase Requests</h1>
        <button className="primary-btn" onClick={() => setShowForm(!showForm)}>
          {showForm ? 'Cancel' : 'Create PR'}
        </button>
      </div>

      {showForm && (
        <div className="pr-form card">
          <h2>New Purchase Request</h2>
          <form onSubmit={handleSubmit}>
            <div className="form-row">
              <div className="form-group">
                <label>Request Date *</label>
                <input type="date" value={formData.request_date} onChange={(e) => setFormData({ ...formData, request_date: e.target.value })} required />
              </div>
              <div className="form-group">
                <label>Required Date</label>
                <input type="date" value={formData.required_date} onChange={(e) => setFormData({ ...formData, required_date: e.target.value })} />
              </div>
            </div>

            <h3>Items</h3>
            <table className="items-table">
              <thead>
                <tr>
                  <th>Item</th>
                  <th>Quantity</th>
                  <th>Expected Price</th>
                  <th>Required Date</th>
                  <th>Remarks</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {formData.items.map((item, index) => (
                  <tr key={index}>
                    <td>
                      <select value={item.item_id} onChange={(e) => handleItemChange(index, 'item_id', e.target.value)} required>
                        <option value="">-- Select Item --</option>
                        {items.map(i => <option key={i.id} value={i.id}>{i.item_code} - {i.item_name}</option>)}
                      </select>
                    </td>
                    <td><input type="number" value={item.quantity} onChange={(e) => handleItemChange(index, 'quantity', e.target.value)} required /></td>
                    <td><input type="number" step="0.01" value={item.expected_price} onChange={(e) => handleItemChange(index, 'expected_price', e.target.value)} /></td>
                    <td><input type="date" value={item.required_date} onChange={(e) => handleItemChange(index, 'required_date', e.target.value)} /></td>
                    <td><input type="text" value={item.remarks} onChange={(e) => handleItemChange(index, 'remarks', e.target.value)} /></td>
                    <td><button type="button" onClick={() => removeItem(index)} className="remove-btn">×</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
            <button type="button" onClick={addItem} className="add-item-btn">+ Add Item</button>

            <div className="form-group">
              <label>Notes</label>
              <textarea value={formData.notes} onChange={(e) => setFormData({ ...formData, notes: e.target.value })} rows="2"></textarea>
            </div>

            <button type="submit" className="primary-btn">Create PR</button>
          </form>
        </div>
      )}

      <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
        <table className="data-table">
          <thead>
            <tr>
              <th>PR Number</th>
              <th>Request Date</th>
              <th>Requested By</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {prs.map(pr => (
              <tr key={pr.id}>
                <td style={{ padding: '12px 16px', borderBottom: '1px solid var(--border-color)' }}>{pr.request_number}</td>
                <td style={{ padding: '12px 16px', borderBottom: '1px solid var(--border-color)' }}>{new Date(pr.request_date).toLocaleDateString()}</td>
                <td style={{ padding: '12px 16px', borderBottom: '1px solid var(--border-color)' }}>{pr.first_name} {pr.last_name}</td>
                <td style={{ padding: '12px 16px', borderBottom: '1px solid var(--border-color)' }}><span className={`status-badge ${pr.status}`}>{pr.status.replace('_', ' ')}</span></td>
                <td style={{ padding: '12px 16px', borderBottom: '1px solid var(--border-color)' }}>
                  {pr.status === 'pending_approval' && (
                    <button className="secondary-btn" onClick={() => handleApprove(pr.id)}>Approve</button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
