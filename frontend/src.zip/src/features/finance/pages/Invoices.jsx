import { useState, useEffect } from 'react';
import api from '@/services/api/client';
import './Invoices.css';

export default function Invoices() {
  const [invoices, setInvoices] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [accounts, setAccounts] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [filters, setFilters] = useState({ status: '' });
  const [formData, setFormData] = useState({
    customer_id: '',
    invoice_date: new Date().toISOString().split('T')[0],
    due_date: '',
    items: [{ description: '', quantity: 1, unit_price: 0, tax_rate: 0, amount: 0 }],
    notes: '',
    accounts_receivable_id: '',
    revenue_account_id: '',
    tax_account_id: ''
  });

  useEffect(() => {
    fetchInvoices();
    fetchCustomers();
    fetchAccounts();
  }, [filters]);

  const fetchInvoices = async () => {
    try {
      const response = await api.get('/finance/invoices', { params: filters });
      setInvoices(response.data);
    } catch (error) {
      console.error('Error fetching invoices:', error);
    }
  };

  const fetchCustomers = async () => {
    try {
      const response = await api.get('/finance/parties', { params: { party_type: 'Customer' } });
      setCustomers(response.data);
    } catch (error) {
      console.error('Error fetching customers:', error);
    }
  };

  const fetchAccounts = async () => {
    try {
      const response = await api.get('/finance/accounts');
      setAccounts(response.data);
    } catch (error) {
      console.error('Error fetching accounts:', error);
    }
  };

  const handleItemChange = (index, field, value) => {
    const newItems = [...formData.items];
    newItems[index][field] = value;
    
    if (field === 'quantity' || field === 'unit_price' || field === 'tax_rate') {
      const qty = parseFloat(newItems[index].quantity) || 0;
      const price = parseFloat(newItems[index].unit_price) || 0;
      const taxRate = parseFloat(newItems[index].tax_rate) || 0;
      newItems[index].amount = qty * price * (1 + taxRate / 100);
    }
    
    setFormData({ ...formData, items: newItems });
  };

  const addItem = () => {
    setFormData({
      ...formData,
      items: [...formData.items, { description: '', quantity: 1, unit_price: 0, tax_rate: 0, amount: 0 }]
    });
  };

  const removeItem = (index) => {
    const newItems = formData.items.filter((_, i) => i !== index);
    setFormData({ ...formData, items: newItems });
  };

  const calculateTotals = () => {
    const subtotal = formData.items.reduce((sum, item) => {
      const qty = parseFloat(item.quantity) || 0;
      const price = parseFloat(item.unit_price) || 0;
      return sum + (qty * price);
    }, 0);
    
    const taxAmount = formData.items.reduce((sum, item) => {
      const qty = parseFloat(item.quantity) || 0;
      const price = parseFloat(item.unit_price) || 0;
      const taxRate = parseFloat(item.tax_rate) || 0;
      return sum + (qty * price * taxRate / 100);
    }, 0);
    
    return { subtotal, taxAmount, total: subtotal + taxAmount };
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const totals = calculateTotals();
      await api.post('/finance/invoices', {
        ...formData,
        subtotal: totals.subtotal,
        tax_amount: totals.taxAmount,
        total_amount: totals.total
      });
      alert('Invoice created successfully');
      setShowForm(false);
      fetchInvoices();
      setFormData({
        customer_id: '',
        invoice_date: new Date().toISOString().split('T')[0],
        due_date: '',
        items: [{ description: '', quantity: 1, unit_price: 0, tax_rate: 0, amount: 0 }],
        notes: '',
        accounts_receivable_id: '',
        revenue_account_id: '',
        tax_account_id: ''
      });
    } catch (error) {
      alert('Error creating invoice: ' + error.message);
    }
  };

  const totals = calculateTotals();

  return (
    <div className="invoices-page">
      <div className="page-header">
        <h1>Customer Invoices</h1>
        <button className="primary-btn" onClick={() => setShowForm(!showForm)}>
          {showForm ? 'Cancel' : 'Create Invoice'}
        </button>
      </div>

      {showForm && (
        <div className="invoice-form widget">
          <h2>New Invoice</h2>
          <form onSubmit={handleSubmit}>
            <div className="form-row">
              <div className="form-group">
                <label>Customer *</label>
                <select value={formData.customer_id} onChange={(e) => setFormData({ ...formData, customer_id: e.target.value })} required>
                  <option value="">-- Select Customer --</option>
                  {customers.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
              <div className="form-group">
                <label>Invoice Date *</label>
                <input type="date" value={formData.invoice_date} onChange={(e) => setFormData({ ...formData, invoice_date: e.target.value })} required />
              </div>
              <div className="form-group">
                <label>Due Date *</label>
                <input type="date" value={formData.due_date} onChange={(e) => setFormData({ ...formData, due_date: e.target.value })} required />
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label>Accounts Receivable Account *</label>
                <select value={formData.accounts_receivable_id} onChange={(e) => setFormData({ ...formData, accounts_receivable_id: e.target.value })} required>
                  <option value="">-- Select Account --</option>
                  {accounts.filter(a => a.code.startsWith('1')).map(a => <option key={a.id} value={a.id}>{a.code} - {a.name}</option>)}
                </select>
              </div>
              <div className="form-group">
                <label>Revenue Account *</label>
                <select value={formData.revenue_account_id} onChange={(e) => setFormData({ ...formData, revenue_account_id: e.target.value })} required>
                  <option value="">-- Select Account --</option>
                  {accounts.filter(a => a.code.startsWith('4')).map(a => <option key={a.id} value={a.id}>{a.code} - {a.name}</option>)}
                </select>
              </div>
              <div className="form-group">
                <label>Tax Account</label>
                <select value={formData.tax_account_id} onChange={(e) => setFormData({ ...formData, tax_account_id: e.target.value })}>
                  <option value="">-- Select Account --</option>
                  {accounts.filter(a => a.code.startsWith('2')).map(a => <option key={a.id} value={a.id}>{a.code} - {a.name}</option>)}
                </select>
              </div>
            </div>

            <h3>Line Items</h3>
            <table className="items-table">
              <thead>
                <tr>
                  <th>Description</th>
                  <th>Quantity</th>
                  <th>Unit Price</th>
                  <th>Tax %</th>
                  <th>Amount</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {formData.items.map((item, index) => (
                  <tr key={index}>
                    <td><input type="text" value={item.description} onChange={(e) => handleItemChange(index, 'description', e.target.value)} required /></td>
                    <td><input type="number" value={item.quantity} onChange={(e) => handleItemChange(index, 'quantity', e.target.value)} required /></td>
                    <td><input type="number" step="0.01" value={item.unit_price} onChange={(e) => handleItemChange(index, 'unit_price', e.target.value)} required /></td>
                    <td><input type="number" step="0.01" value={item.tax_rate} onChange={(e) => handleItemChange(index, 'tax_rate', e.target.value)} /></td>
                    <td>${item.amount.toFixed(2)}</td>
                    <td><button type="button" onClick={() => removeItem(index)} className="remove-btn">×</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
            <button type="button" onClick={addItem} className="add-item-btn">+ Add Item</button>

            <div className="totals-section">
              <div>Subtotal: ${totals.subtotal.toFixed(2)}</div>
              <div>Tax: ${totals.taxAmount.toFixed(2)}</div>
              <div className="total">Total: ${totals.total.toFixed(2)}</div>
            </div>

            <div className="form-group">
              <label>Notes</label>
              <textarea value={formData.notes} onChange={(e) => setFormData({ ...formData, notes: e.target.value })} rows="3"></textarea>
            </div>

            <button type="submit" className="primary-btn">Create Invoice</button>
          </form>
        </div>
      )}

      <div className="filters">
        <select value={filters.status} onChange={(e) => setFilters({ ...filters, status: e.target.value })}>
          <option value="">All Status</option>
          <option value="Draft">Draft</option>
          <option value="Sent">Sent</option>
          <option value="Paid">Paid</option>
          <option value="Overdue">Overdue</option>
        </select>
      </div>

      <div className="widget">
        <table className="data-table">
          <thead>
            <tr>
              <th>Invoice #</th>
              <th>Customer</th>
              <th>Date</th>
              <th>Due Date</th>
              <th>Amount</th>
              <th>Balance</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {invoices.map(inv => (
              <tr key={inv.id}>
                <td>{inv.invoice_number}</td>
                <td>{inv.customer_name}</td>
                <td>{new Date(inv.invoice_date).toLocaleDateString()}</td>
                <td>{new Date(inv.due_date).toLocaleDateString()}</td>
                <td>${parseFloat(inv.total_amount).toLocaleString()}</td>
                <td>${parseFloat(inv.balance).toLocaleString()}</td>
                <td><span className={`status-badge ${inv.status.toLowerCase()}`}>{inv.status}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
