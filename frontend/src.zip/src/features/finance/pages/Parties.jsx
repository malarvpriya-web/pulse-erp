import { useState, useEffect } from 'react';
import api from '@/services/api/client';
import './Parties.css';

export default function Parties() {
  const [parties, setParties] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [filter, setFilter] = useState('');
  const [formData, setFormData] = useState({
    party_type: 'Customer',
    name: '',
    contact_person: '',
    email: '',
    phone: '',
    address: '',
    tax_id: '',
    credit_limit: 0,
    payment_terms: 30
  });

  useEffect(() => {
    fetchParties();
  }, [filter]);

  const fetchParties = async () => {
    try {
      const params = filter ? { party_type: filter } : {};
      const response = await api.get('/finance/parties', { params });
      setParties(response.data);
    } catch (error) {
      console.error('Error fetching parties:', error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await api.post('/finance/parties', formData);
      alert('Party created successfully');
      setShowForm(false);
      fetchParties();
      setFormData({
        party_type: 'Customer',
        name: '',
        contact_person: '',
        email: '',
        phone: '',
        address: '',
        tax_id: '',
        credit_limit: 0,
        payment_terms: 30
      });
    } catch (error) {
      alert('Error creating party: ' + error.message);
    }
  };

  return (
    <div className="parties-page">
      <div className="page-header">
        <h1>Customers & Suppliers</h1>
        <button className="primary-btn" onClick={() => setShowForm(!showForm)}>
          {showForm ? 'Cancel' : 'Add Party'}
        </button>
      </div>

      {showForm && (
        <div className="party-form widget">
          <h2>New Party</h2>
          <form onSubmit={handleSubmit}>
            <div className="form-row">
              <div className="form-group">
                <label>Party Type *</label>
                <select value={formData.party_type} onChange={(e) => setFormData({ ...formData, party_type: e.target.value })} required>
                  <option value="Customer">Customer</option>
                  <option value="Supplier">Supplier</option>
                  <option value="Both">Both</option>
                </select>
              </div>
              <div className="form-group">
                <label>Name *</label>
                <input type="text" value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} required />
              </div>
              <div className="form-group">
                <label>Contact Person</label>
                <input type="text" value={formData.contact_person} onChange={(e) => setFormData({ ...formData, contact_person: e.target.value })} />
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label>Email</label>
                <input type="email" value={formData.email} onChange={(e) => setFormData({ ...formData, email: e.target.value })} />
              </div>
              <div className="form-group">
                <label>Phone</label>
                <input type="text" value={formData.phone} onChange={(e) => setFormData({ ...formData, phone: e.target.value })} />
              </div>
              <div className="form-group">
                <label>Tax ID</label>
                <input type="text" value={formData.tax_id} onChange={(e) => setFormData({ ...formData, tax_id: e.target.value })} />
              </div>
            </div>

            <div className="form-group">
              <label>Address</label>
              <textarea value={formData.address} onChange={(e) => setFormData({ ...formData, address: e.target.value })} rows="2"></textarea>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label>Credit Limit</label>
                <input type="number" step="0.01" value={formData.credit_limit} onChange={(e) => setFormData({ ...formData, credit_limit: e.target.value })} />
              </div>
              <div className="form-group">
                <label>Payment Terms (days)</label>
                <input type="number" value={formData.payment_terms} onChange={(e) => setFormData({ ...formData, payment_terms: e.target.value })} />
              </div>
            </div>

            <button type="submit" className="primary-btn">Create Party</button>
          </form>
        </div>
      )}

      <div className="filters">
        <select value={filter} onChange={(e) => setFilter(e.target.value)}>
          <option value="">All Parties</option>
          <option value="Customer">Customers</option>
          <option value="Supplier">Suppliers</option>
        </select>
      </div>

      <div className="widget">
        <table className="data-table">
          <thead>
            <tr>
              <th>Code</th>
              <th>Name</th>
              <th>Type</th>
              <th>Contact Person</th>
              <th>Email</th>
              <th>Phone</th>
              <th>Payment Terms</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {parties.map(party => (
              <tr key={party.id}>
                <td>{party.party_code}</td>
                <td>{party.name}</td>
                <td><span className={`type-badge ${party.party_type.toLowerCase()}`}>{party.party_type}</span></td>
                <td>{party.contact_person || '-'}</td>
                <td>{party.email || '-'}</td>
                <td>{party.phone || '-'}</td>
                <td>{party.payment_terms} days</td>
                <td><span className={`status-badge ${party.is_active ? 'active' : 'inactive'}`}>{party.is_active ? 'Active' : 'Inactive'}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
