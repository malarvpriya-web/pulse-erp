import { useState, useEffect } from 'react';
import api from '@/services/api/client';
import './FinancialRatios.css';

export default function FinancialRatios() {
  const [ratios, setRatios] = useState(null);
  const [loading, setLoading] = useState(false);
  const [asOfDate, setAsOfDate] = useState(new Date().toISOString().split('T')[0]);

  useEffect(() => {
    fetchRatios();
  }, []);

  const fetchRatios = async () => {
    setLoading(true);
    try {
      const response = await api.get('/finance/ratios', { params: { as_of_date: asOfDate } });
      setRatios(response.data);
    } catch (error) {
      console.error('Error fetching ratios:', error);
    } finally {
      setLoading(false);
    }
  };

  const getRatioStatus = (ratio, type) => {
    const value = parseFloat(ratio);
    if (type === 'current_ratio') {
      if (value >= 2) return 'excellent';
      if (value >= 1.5) return 'good';
      if (value >= 1) return 'fair';
      return 'poor';
    }
    if (type === 'quick_ratio') {
      if (value >= 1) return 'good';
      return 'fair';
    }
    if (type === 'debt_to_equity') {
      if (value <= 1) return 'excellent';
      if (value <= 2) return 'good';
      return 'fair';
    }
    return 'neutral';
  };

  if (loading) return <div className="loading">Loading ratios...</div>;
  if (!ratios) return <div className="error">Failed to load ratios</div>;

  return (
    <div className="ratios-page">
      <div className="page-header">
        <h1>Financial Ratios & Analysis</h1>
        <div className="date-selector">
          <label>As of Date:</label>
          <input type="date" value={asOfDate} onChange={(e) => setAsOfDate(e.target.value)} />
          <button className="primary-btn" onClick={fetchRatios}>Calculate</button>
        </div>
      </div>

      <div className="ratios-grid">
        <div className="ratio-section widget">
          <h2>Liquidity Ratios</h2>
          <div className="ratio-items">
            <div className={`ratio-item ${getRatioStatus(ratios.current_ratio, 'current_ratio')}`}>
              <div className="ratio-label">Current Ratio</div>
              <div className="ratio-value">{ratios.current_ratio}</div>
              <div className="ratio-desc">Current Assets / Current Liabilities</div>
            </div>
            <div className={`ratio-item ${getRatioStatus(ratios.quick_ratio, 'quick_ratio')}`}>
              <div className="ratio-label">Quick Ratio</div>
              <div className="ratio-value">{ratios.quick_ratio}</div>
              <div className="ratio-desc">(Current Assets - Inventory) / Current Liabilities</div>
            </div>
            <div className="ratio-item">
              <div className="ratio-label">Cash Ratio</div>
              <div className="ratio-value">{ratios.cash_ratio}</div>
              <div className="ratio-desc">Cash / Current Liabilities</div>
            </div>
            <div className="ratio-item">
              <div className="ratio-label">Working Capital</div>
              <div className="ratio-value">${parseFloat(ratios.working_capital).toLocaleString()}</div>
              <div className="ratio-desc">Current Assets - Current Liabilities</div>
            </div>
          </div>
        </div>

        <div className="ratio-section widget">
          <h2>Profitability Ratios</h2>
          <div className="ratio-items">
            <div className="ratio-item">
              <div className="ratio-label">Gross Margin</div>
              <div className="ratio-value">{ratios.gross_margin}%</div>
              <div className="ratio-desc">(Revenue - COGS) / Revenue</div>
            </div>
            <div className="ratio-item">
              <div className="ratio-label">Operating Margin</div>
              <div className="ratio-value">{ratios.operating_margin}%</div>
              <div className="ratio-desc">Operating Income / Revenue</div>
            </div>
            <div className="ratio-item">
              <div className="ratio-label">Net Margin</div>
              <div className="ratio-value">{ratios.net_margin}%</div>
              <div className="ratio-desc">Net Profit / Revenue</div>
            </div>
            <div className="ratio-item">
              <div className="ratio-label">Return on Assets</div>
              <div className="ratio-value">{ratios.return_on_assets}%</div>
              <div className="ratio-desc">Net Profit / Total Assets</div>
            </div>
            <div className="ratio-item">
              <div className="ratio-label">Return on Equity</div>
              <div className="ratio-value">{ratios.return_on_equity}%</div>
              <div className="ratio-desc">Net Profit / Total Equity</div>
            </div>
          </div>
        </div>

        <div className="ratio-section widget">
          <h2>Efficiency Ratios</h2>
          <div className="ratio-items">
            <div className="ratio-item">
              <div className="ratio-label">Asset Turnover</div>
              <div className="ratio-value">{ratios.asset_turnover}x</div>
              <div className="ratio-desc">Revenue / Total Assets</div>
            </div>
            <div className="ratio-item">
              <div className="ratio-label">Inventory Turnover</div>
              <div className="ratio-value">{ratios.inventory_turnover}x</div>
              <div className="ratio-desc">COGS / Inventory</div>
            </div>
            <div className="ratio-item">
              <div className="ratio-label">Receivables Turnover</div>
              <div className="ratio-value">{ratios.receivables_turnover}x</div>
              <div className="ratio-desc">Revenue / Receivables</div>
            </div>
            <div className="ratio-item">
              <div className="ratio-label">Days Sales Outstanding</div>
              <div className="ratio-value">{ratios.days_sales_outstanding} days</div>
              <div className="ratio-desc">Average collection period</div>
            </div>
            <div className="ratio-item">
              <div className="ratio-label">Days Payable Outstanding</div>
              <div className="ratio-value">{ratios.days_payable_outstanding} days</div>
              <div className="ratio-desc">Average payment period</div>
            </div>
          </div>
        </div>

        <div className="ratio-section widget">
          <h2>Leverage Ratios</h2>
          <div className="ratio-items">
            <div className={`ratio-item ${getRatioStatus(ratios.debt_to_equity, 'debt_to_equity')}`}>
              <div className="ratio-label">Debt to Equity</div>
              <div className="ratio-value">{ratios.debt_to_equity}</div>
              <div className="ratio-desc">Total Liabilities / Total Equity</div>
            </div>
            <div className="ratio-item">
              <div className="ratio-label">Debt to Assets</div>
              <div className="ratio-value">{ratios.debt_to_assets}%</div>
              <div className="ratio-desc">Total Liabilities / Total Assets</div>
            </div>
            <div className="ratio-item">
              <div className="ratio-label">Equity Ratio</div>
              <div className="ratio-value">{ratios.equity_ratio}%</div>
              <div className="ratio-desc">Total Equity / Total Assets</div>
            </div>
            <div className="ratio-item">
              <div className="ratio-label">Interest Coverage</div>
              <div className="ratio-value">{ratios.interest_coverage}x</div>
              <div className="ratio-desc">EBIT / Interest Expense</div>
            </div>
          </div>
        </div>
      </div>

      <div className="financial-summary widget">
        <h2>Financial Summary</h2>
        <div className="summary-grid">
          <div className="summary-item">
            <div className="summary-label">Total Assets</div>
            <div className="summary-value">${parseFloat(ratios.total_assets).toLocaleString()}</div>
          </div>
          <div className="summary-item">
            <div className="summary-label">Total Liabilities</div>
            <div className="summary-value">${parseFloat(ratios.total_liabilities).toLocaleString()}</div>
          </div>
          <div className="summary-item">
            <div className="summary-label">Total Equity</div>
            <div className="summary-value">${parseFloat(ratios.total_equity).toLocaleString()}</div>
          </div>
          <div className="summary-item">
            <div className="summary-label">Revenue</div>
            <div className="summary-value">${parseFloat(ratios.revenue).toLocaleString()}</div>
          </div>
          <div className="summary-item">
            <div className="summary-label">Net Profit</div>
            <div className="summary-value">${parseFloat(ratios.net_profit).toLocaleString()}</div>
          </div>
        </div>
      </div>
    </div>
  );
}
