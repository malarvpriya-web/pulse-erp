import { useState } from 'react';
import api from '@/services/api/client';
import './Reports.css';

export default function Reports() {
  const [reportType, setReportType] = useState('profit-loss');
  const [reportData, setReportData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [filters, setFilters] = useState({
    start_date: new Date(new Date().getFullYear(), 0, 1).toISOString().split('T')[0],
    end_date: new Date().toISOString().split('T')[0],
    as_of_date: new Date().toISOString().split('T')[0]
  });

  const fetchReport = async () => {
    setLoading(true);
    try {
      let response;
      switch (reportType) {
        case 'profit-loss':
          response = await api.get('/finance/reports/profit-loss', { params: { start_date: filters.start_date, end_date: filters.end_date } });
          break;
        case 'balance-sheet':
          response = await api.get('/finance/reports/balance-sheet', { params: { as_of_date: filters.as_of_date } });
          break;
        case 'customer-outstanding':
          response = await api.get('/finance/reports/customer-outstanding');
          break;
        case 'supplier-outstanding':
          response = await api.get('/finance/reports/supplier-outstanding');
          break;
        default:
          return;
      }
      setReportData(response.data);
    } catch (error) {
      alert('Error fetching report: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="reports-page">
      <h1>Financial Reports</h1>

      <div className="report-controls widget">
        <div className="form-row">
          <div className="form-group">
            <label>Report Type</label>
            <select value={reportType} onChange={(e) => { setReportType(e.target.value); setReportData(null); }}>
              <option value="profit-loss">Profit & Loss</option>
              <option value="balance-sheet">Balance Sheet</option>
              <option value="customer-outstanding">Customer Outstanding</option>
              <option value="supplier-outstanding">Supplier Outstanding</option>
            </select>
          </div>

          {(reportType === 'profit-loss') && (
            <>
              <div className="form-group">
                <label>Start Date</label>
                <input type="date" value={filters.start_date} onChange={(e) => setFilters({ ...filters, start_date: e.target.value })} />
              </div>
              <div className="form-group">
                <label>End Date</label>
                <input type="date" value={filters.end_date} onChange={(e) => setFilters({ ...filters, end_date: e.target.value })} />
              </div>
            </>
          )}

          {reportType === 'balance-sheet' && (
            <div className="form-group">
              <label>As of Date</label>
              <input type="date" value={filters.as_of_date} onChange={(e) => setFilters({ ...filters, as_of_date: e.target.value })} />
            </div>
          )}

          <button className="primary-btn" onClick={fetchReport} disabled={loading}>
            {loading ? 'Loading...' : 'Generate Report'}
          </button>
        </div>
      </div>

      {reportData && (
        <div className="report-content widget">
          {reportType === 'profit-loss' && (
            <div className="profit-loss-report">
              <h2>Profit & Loss Statement</h2>
              <p className="report-period">Period: {filters.start_date} to {filters.end_date}</p>

              <div className="report-section">
                <h3>Revenue</h3>
                <table className="report-table">
                  <tbody>
                    {reportData.revenue_accounts.map(acc => (
                      <tr key={acc.code}>
                        <td>{acc.code} - {acc.name}</td>
                        <td className="amount">${(parseFloat(acc.total_credit) - parseFloat(acc.total_debit)).toLocaleString()}</td>
                      </tr>
                    ))}
                    <tr className="total-row">
                      <td><strong>Total Revenue</strong></td>
                      <td className="amount"><strong>${reportData.total_revenue.toLocaleString()}</strong></td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <div className="report-section">
                <h3>Expenses</h3>
                <table className="report-table">
                  <tbody>
                    {reportData.expense_accounts.map(acc => (
                      <tr key={acc.code}>
                        <td>{acc.code} - {acc.name}</td>
                        <td className="amount">${(parseFloat(acc.total_debit) - parseFloat(acc.total_credit)).toLocaleString()}</td>
                      </tr>
                    ))}
                    <tr className="total-row">
                      <td><strong>Total Expenses</strong></td>
                      <td className="amount"><strong>${reportData.total_expenses.toLocaleString()}</strong></td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <div className="net-profit">
                <h3>Net Profit</h3>
                <div className={`profit-amount ${reportData.net_profit >= 0 ? 'positive' : 'negative'}`}>
                  ${reportData.net_profit.toLocaleString()}
                </div>
              </div>
            </div>
          )}

          {reportType === 'balance-sheet' && (
            <div className="balance-sheet-report">
              <h2>Balance Sheet</h2>
              <p className="report-period">As of: {filters.as_of_date}</p>

              <div className="report-section">
                <h3>Assets</h3>
                <table className="report-table">
                  <tbody>
                    {reportData.asset_accounts.map(acc => (
                      <tr key={acc.code}>
                        <td>{acc.code} - {acc.name}</td>
                        <td className="amount">${(parseFloat(acc.total_debit) - parseFloat(acc.total_credit)).toLocaleString()}</td>
                      </tr>
                    ))}
                    <tr className="total-row">
                      <td><strong>Total Assets</strong></td>
                      <td className="amount"><strong>${reportData.total_assets.toLocaleString()}</strong></td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <div className="report-section">
                <h3>Liabilities</h3>
                <table className="report-table">
                  <tbody>
                    {reportData.liability_accounts.map(acc => (
                      <tr key={acc.code}>
                        <td>{acc.code} - {acc.name}</td>
                        <td className="amount">${(parseFloat(acc.total_credit) - parseFloat(acc.total_debit)).toLocaleString()}</td>
                      </tr>
                    ))}
                    <tr className="total-row">
                      <td><strong>Total Liabilities</strong></td>
                      <td className="amount"><strong>${reportData.total_liabilities.toLocaleString()}</strong></td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <div className="report-section">
                <h3>Equity</h3>
                <table className="report-table">
                  <tbody>
                    {reportData.equity_accounts.map(acc => (
                      <tr key={acc.code}>
                        <td>{acc.code} - {acc.name}</td>
                        <td className="amount">${(parseFloat(acc.total_credit) - parseFloat(acc.total_debit)).toLocaleString()}</td>
                      </tr>
                    ))}
                    <tr className="total-row">
                      <td><strong>Total Equity</strong></td>
                      <td className="amount"><strong>${reportData.total_equity.toLocaleString()}</strong></td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {(reportType === 'customer-outstanding' || reportType === 'supplier-outstanding') && (
            <div className="outstanding-report">
              <h2>{reportType === 'customer-outstanding' ? 'Customer' : 'Supplier'} Outstanding</h2>
              <table className="report-table">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Outstanding Balance</th>
                  </tr>
                </thead>
                <tbody>
                  {reportData.map((item, index) => (
                    <tr key={index}>
                      <td>{item.customer_name || item.supplier_name}</td>
                      <td className="amount">${item.outstanding_balance.toLocaleString()}</td>
                    </tr>
                  ))}
                  <tr className="total-row">
                    <td><strong>Total Outstanding</strong></td>
                    <td className="amount"><strong>${reportData.reduce((sum, item) => sum + item.outstanding_balance, 0).toLocaleString()}</strong></td>
                  </tr>
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
