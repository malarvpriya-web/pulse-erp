import { useState, useEffect } from 'react';
import api from '@/services/api/client';
import './FinanceDashboard.css';

export default function FinanceDashboard() {
  const [dashboard, setDashboard] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboard();
  }, []);

  const fetchDashboard = async () => {
    try {
      const response = await api.get('/finance/dashboard');
      setDashboard(response.data);
    } catch (error) {
      console.error('Error fetching dashboard:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <div className="loading">Loading dashboard...</div>;
  if (!dashboard) return <div className="error">Failed to load dashboard</div>;

  return (
    <div className="finance-dashboard">
      <h1>Finance Dashboard</h1>

      <div className="kpi-grid">
        <div className="kpi-card">
          <h3>Monthly Revenue</h3>
          <div className="kpi-value">${dashboard.monthly_revenue.toLocaleString()}</div>
        </div>
        <div className="kpi-card">
          <h3>Monthly Expenses</h3>
          <div className="kpi-value">${dashboard.monthly_expenses.toLocaleString()}</div>
        </div>
        <div className="kpi-card">
          <h3>Net Profit</h3>
          <div className="kpi-value">${(dashboard.monthly_revenue - dashboard.monthly_expenses).toLocaleString()}</div>
        </div>
        <div className="kpi-card alert">
          <h3>Overdue Invoices</h3>
          <div className="kpi-value">{dashboard.overdue_invoices}</div>
          <div className="kpi-sub">${dashboard.overdue_amount.toLocaleString()}</div>
        </div>
        <div className="kpi-card warning">
          <h3>Due Soon (7 days)</h3>
          <div className="kpi-value">{dashboard.due_soon_invoices} Invoices</div>
          <div className="kpi-sub">{dashboard.due_soon_bills} Bills</div>
        </div>
        <div className="kpi-card">
          <h3>Pending Approvals</h3>
          <div className="kpi-value">{dashboard.pending_approvals}</div>
        </div>
      </div>

      <div className="alerts-section">
        <h2>Alerts & Notifications</h2>
        {dashboard.alerts.length === 0 ? (
          <p>No alerts at this time</p>
        ) : (
          <div className="alerts-list">
            {dashboard.alerts.map((alert, index) => (
              <div key={index} className={`alert-item ${alert.type}`}>
                <div className="alert-icon">
                  {alert.type.includes('overdue') ? '🔴' : '⚠️'}
                </div>
                <div className="alert-content">
                  <p>{alert.message}</p>
                  <span className="alert-amount">${alert.amount.toLocaleString()}</span>
                  <span className="alert-party">{alert.customer || alert.supplier}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
