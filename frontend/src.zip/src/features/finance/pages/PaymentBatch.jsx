import { useState, useEffect } from 'react';
import api from '@/services/api/client';
import './PaymentBatch.css';

export default function PaymentBatch() {
  const [batches, setBatches] = useState([]);
  const [suppliers, setSuppliers] = useState([]);
  const [bills, setBills] = useState([]);
  const [bankAccounts, setBankAccounts] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [selectedBatch, setSelectedBatch] = useState(null);
  const [formData, setFormData] = useState({
    batch_date: new Date().toISOString().split('T')[0],
    bank_account_id: '',
    notes: '',
    items: []
  });

  useEffect(() => {
    fetchBatches();
    fetchSuppliers();
    fetchBankAccounts();
  }, []);

  const fetchBatches = async () => {
    try {
      const response = await api.get('/finance/payment-batches');
      setBatches(response.data);
    } catch (error) {
      console.error('Error fetching batches:', error);
    }
  };

  const fetchSuppliers = async () => {
    try {
      const response = await api.get('/finance/parties', { params: { party_type: 'Supplier' } });
      setSuppliers(response.data);
    } catch (error) {
      console.error('Error fetching suppliers:', error);
    }
  };

  const fetchBankAccounts = async () => {
    try {
      const response = await api.get('/finance/bank-accounts');
      setBankAccounts(response.data);
    } catch (error) {
      console.error('Error fetching bank accounts:', error);
    }
  };

  const fetchSupplierBills = async (supplierId) => {
    try {
      const response = await api.get('/finance/bills', { params: { supplier_id: supplierId, status: 'Approved' } });
      setBills(response.data.filter(b => b.balance > 0));
    } catch (error) {
      console.error('Error fetching bills:', error);
    }
  };

  const addItem = () => {
    setFormData({
      ...formData,
      items: [...formData.items, { party_id: '', bill_id: '', amount: 0, payment_method: 'Bank Transfer', reference_number: '', notes: '' }]
    });
  };

  const removeItem = (index) => {
    const newItems = formData.items.filter((_, i) => i !== index);
    setFormData({ ...formData, items: newItems });
  };

  const handleItemChange = (index, field, value) => {
    const newItems = [...formData.items];
    newItems[index][field] = value;
    
    if (field === 'party_id') {
      fetchSupplierBills(value);
      newItems[index].bill_id = '';
    }
    
    if (field === 'bill_id') {
      const bill = bills.find(b => b.id === value);
      if (bill) {
        newItems[index].amount = bill.balance;
      }
    }
    
    setFormData({ ...formData, items: newItems });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await api.post('/finance/payment-batches', formData);
      alert('Payment batch created successfully');
      setShowForm(false);
      fetchBatches();
      setFormData({
        batch_date: new Date().toISOString().split('T')[0],
        bank_account_id: '',
        notes: '',
        items: []
      });
    } catch (error) {
      alert('Error creating batch: ' + error.message);
    }
  };

  const handleAction = async (batchId, action) => {
    try {
      if (action === 'submit') {
        await api.post(`/finance/payment-batches/${batchId}/submit`);
        alert('Batch submitted for approval');
      } else if (action === 'approve') {
        await api.post(`/finance/payment-batches/${batchId}/approve`);
        alert('Batch approved');
      } else if (action === 'process') {
        const accounts = {
          accounts_payable_id: prompt('Enter Accounts Payable Account ID'),
          bank_account_chart_id: prompt('Enter Bank Account Chart ID')
        };
        await api.post(`/finance/payment-batches/${batchId}/process`, accounts);
        alert('Batch processed successfully');
      }
      fetchBatches();
    } catch (error) {
      alert('Error: ' + error.message);
    }
  };

  const totalAmount = formData.items.reduce((sum, item) => sum + parseFloat(item.amount || 0), 0);

  return (
    <div className="payment-batch-page">
      <div className="page-header">
        <h1>Payment Batches</h1>
        <button className="primary-btn" onClick={() => setShowForm(!showForm)}>
          {showForm ? 'Cancel' : 'Create Batch'}
        </button>
      </div>

      {showForm && (
        <div className="batch-form widget">
          <h2>New Payment Batch</h2>
          <form onSubmit={handleSubmit}>
            <div className="form-row">
              <div className="form-group">
                <label>Batch Date *</label>
                <input type="date" value={formData.batch_date} onChange={(e) => setFormData({ ...formData, batch_date: e.target.value })} required />
              </div>
              <div className="form-group">
                <label>Bank Account *</label>
                <select value={formData.bank_account_id} onChange={(e) => setFormData({ ...formData, bank_account_id: e.target.value })} required>
                  <option value="">-- Select Bank Account --</option>
                  {bankAccounts.map(ba => <option key={ba.id} value={ba.id}>{ba.account_name} - {ba.account_number}</option>)}
                </select>
              </div>
            </div>

            <h3>Payment Items</h3>
            <table className="items-table">
              <thead>
                <tr>
                  <th>Supplier</th>
                  <th>Bill</th>
                  <th>Amount</th>
                  <th>Payment Method</th>
                  <th>Reference</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {formData.items.map((item, index) => (
                  <tr key={index}>
                    <td>
                      <select value={item.party_id} onChange={(e) => handleItemChange(index, 'party_id', e.target.value)} required>
                        <option value="">-- Select Supplier --</option>
                        {suppliers.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                      </select>
                    </td>
                    <td>
                      <select value={item.bill_id} onChange={(e) => handleItemChange(index, 'bill_id', e.target.value)}>
                        <option value="">-- Select Bill --</option>
                        {bills.map(b => <option key={b.id} value={b.id}>{b.bill_number} - ${b.balance}</option>)}
                      </select>
                    </td>
                    <td><input type="number" step="0.01" value={item.amount} onChange={(e) => handleItemChange(index, 'amount', e.target.value)} required /></td>
                    <td>
                      <select value={item.payment_method} onChange={(e) => handleItemChange(index, 'payment_method', e.target.value)}>
                        <option>Bank Transfer</option>
                        <option>Cheque</option>
                        <option>Cash</option>
                      </select>
                    </td>
                    <td><input type="text" value={item.reference_number} onChange={(e) => handleItemChange(index, 'reference_number', e.target.value)} /></td>
                    <td><button type="button" onClick={() => removeItem(index)} className="remove-btn">×</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
            <button type="button" onClick={addItem} className="add-item-btn">+ Add Payment</button>

            <div className="totals-section">
              <div className="total">Total Amount: ${totalAmount.toFixed(2)}</div>
              <div>Payment Count: {formData.items.length}</div>
            </div>

            <div className="form-group">
              <label>Notes</label>
              <textarea value={formData.notes} onChange={(e) => setFormData({ ...formData, notes: e.target.value })} rows="2"></textarea>
            </div>

            <button type="submit" className="primary-btn">Create Batch</button>
          </form>
        </div>
      )}

      <div className="widget">
        <table className="data-table">
          <thead>
            <tr>
              <th>Batch #</th>
              <th>Date</th>
              <th>Payment Count</th>
              <th>Total Amount</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {batches.map(batch => (
              <tr key={batch.id}>
                <td>{batch.batch_number}</td>
                <td>{new Date(batch.batch_date).toLocaleDateString()}</td>
                <td>{batch.payment_count}</td>
                <td>${parseFloat(batch.total_amount).toLocaleString()}</td>
                <td><span className={`status-badge ${batch.status.toLowerCase()}`}>{batch.status.replace('_', ' ')}</span></td>
                <td>
                  {batch.status === 'Draft' && (
                    <button className="action-btn" onClick={() => handleAction(batch.id, 'submit')}>Submit</button>
                  )}
                  {batch.status === 'Awaiting_Approval' && (
                    <button className="action-btn" onClick={() => handleAction(batch.id, 'approve')}>Approve</button>
                  )}
                  {batch.status === 'Approved' && (
                    <button className="action-btn" onClick={() => handleAction(batch.id, 'process')}>Process</button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
