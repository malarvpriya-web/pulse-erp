import { useState, useEffect } from 'react';
import api from '@/services/api/client';
import './ChartOfAccounts.css';

export default function ChartOfAccounts() {
  const [accounts, setAccounts] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    code: '',
    name: '',
    account_type: 'Asset',
    parent_id: '',
    description: ''
  });

  useEffect(() => {
    fetchAccounts();
  }, []);

  const fetchAccounts = async () => {
    try {
      const response = await api.get('/finance/accounts/tree');
      setAccounts(response.data);
    } catch (error) {
      console.error('Error fetching accounts:', error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await api.post('/finance/accounts', formData);
      alert('Account created successfully');
      setShowForm(false);
      fetchAccounts();
      setFormData({
        code: '',
        name: '',
        account_type: 'Asset',
        parent_id: '',
        description: ''
      });
    } catch (error) {
      alert('Error creating account: ' + error.message);
    }
  };

  const groupByType = () => {
    const grouped = {};
    accounts.forEach(acc => {
      if (!grouped[acc.account_type]) {
        grouped[acc.account_type] = [];
      }
      grouped[acc.account_type].push(acc);
    });
    return grouped;
  };

  const grouped = groupByType();

  return (
    <div className="coa-page">
      <div className="page-header">
        <h1>Chart of Accounts</h1>
        <button className="primary-btn" onClick={() => setShowForm(!showForm)}>
          {showForm ? 'Cancel' : 'Add Account'}
        </button>
      </div>

      {showForm && (
        <div className="coa-form widget">
          <h2>New Account</h2>
          <form onSubmit={handleSubmit}>
            <div className="form-row">
              <div className="form-group">
                <label>Account Code *</label>
                <input type="text" value={formData.code} onChange={(e) => setFormData({ ...formData, code: e.target.value })} required />
              </div>
              <div className="form-group">
                <label>Account Name *</label>
                <input type="text" value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} required />
              </div>
              <div className="form-group">
                <label>Account Type *</label>
                <select value={formData.account_type} onChange={(e) => setFormData({ ...formData, account_type: e.target.value })} required>
                  <option value="Asset">Asset</option>
                  <option value="Liability">Liability</option>
                  <option value="Equity">Equity</option>
                  <option value="Revenue">Revenue</option>
                  <option value="Expense">Expense</option>
                </select>
              </div>
            </div>

            <div className="form-group">
              <label>Parent Account</label>
              <select value={formData.parent_id} onChange={(e) => setFormData({ ...formData, parent_id: e.target.value })}>
                <option value="">-- None (Top Level) --</option>
                {accounts.map(acc => (
                  <option key={acc.id} value={acc.id}>{acc.code} - {acc.name}</option>
                ))}
              </select>
            </div>

            <div className="form-group">
              <label>Description</label>
              <textarea value={formData.description} onChange={(e) => setFormData({ ...formData, description: e.target.value })} rows="2"></textarea>
            </div>

            <button type="submit" className="primary-btn">Create Account</button>
          </form>
        </div>
      )}

      <div className="widget">
        {Object.keys(grouped).map(type => (
          <div key={type} className="account-type-section">
            <h2 className="account-type-header">{type}</h2>
            <table className="coa-table">
              <thead>
                <tr>
                  <th>Code</th>
                  <th>Name</th>
                  <th>Description</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {grouped[type].map(acc => (
                  <tr key={acc.id} style={{ paddingLeft: `${acc.level * 30}px` }}>
                    <td style={{ paddingLeft: `${acc.level * 30}px` }}>{acc.code}</td>
                    <td>{acc.name}</td>
                    <td>{acc.description || '-'}</td>
                    <td><span className={`status-badge ${acc.is_active ? 'active' : 'inactive'}`}>{acc.is_active ? 'Active' : 'Inactive'}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ))}
      </div>
    </div>
  );
}
