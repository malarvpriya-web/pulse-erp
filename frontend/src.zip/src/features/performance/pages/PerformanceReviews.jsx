import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './PerformanceReviews.css';

const PerformanceReviews = () => {
  const [reviews, setReviews] = useState([]);
  const [selectedReview, setSelectedReview] = useState(null);
  const [showSelfReview, setShowSelfReview] = useState(false);
  const [selfReviewData, setSelfReviewData] = useState({
    self_rating: '',
    self_comments: '',
    achievements: '',
    challenges: ''
  });

  const currentUser = JSON.parse(localStorage.getItem('user') || '{}');

  useEffect(() => {
    fetchReviews();
  }, []);

  const fetchReviews = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await axios.get(`http://localhost:5000/api/performance/reviews?employee_id=${currentUser.id}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setReviews(res.data);
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const handleSelfReviewSubmit = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token');
      await axios.post(`http://localhost:5000/api/performance/reviews/${selectedReview.id}/self-review`,
        selfReviewData,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      alert('Self review submitted successfully');
      setShowSelfReview(false);
      fetchReviews();
      setSelfReviewData({
        self_rating: '',
        self_comments: '',
        achievements: '',
        challenges: ''
      });
    } catch (error) {
      alert('Error submitting self review');
    }
  };

  const getStatusColor = (status) => {
    const colors = {
      draft: '#f3f4f6',
      self_submitted: '#fef3c7',
      manager_review: '#dbeafe',
      completed: '#dcfce7',
      cancelled: '#fee2e2'
    };
    return colors[status] || '#f3f4f6';
  };

  const getRatingStars = (rating) => {
    if (!rating) return '-';
    return '⭐'.repeat(Math.round(rating));
  };

  return (
    <div className="performance-page">
      <div className="performance-header">
        <h1>My Performance Reviews</h1>
      </div>

      {showSelfReview && (
        <div className="form-modal">
          <div className="form-card">
            <h2>Self Review - {selectedReview?.review_period}</h2>
            <form onSubmit={handleSelfReviewSubmit}>
              <div className="form-group">
                <label>Self Rating (1-5) *</label>
                <input
                  type="number"
                  step="0.1"
                  min="1"
                  max="5"
                  value={selfReviewData.self_rating}
                  onChange={(e) => setSelfReviewData({ ...selfReviewData, self_rating: e.target.value })}
                  required
                />
              </div>

              <div className="form-group">
                <label>Achievements *</label>
                <textarea
                  value={selfReviewData.achievements}
                  onChange={(e) => setSelfReviewData({ ...selfReviewData, achievements: e.target.value })}
                  rows="4"
                  placeholder="List your key achievements during this period..."
                  required
                />
              </div>

              <div className="form-group">
                <label>Challenges</label>
                <textarea
                  value={selfReviewData.challenges}
                  onChange={(e) => setSelfReviewData({ ...selfReviewData, challenges: e.target.value })}
                  rows="4"
                  placeholder="Describe any challenges you faced..."
                />
              </div>

              <div className="form-group">
                <label>Overall Comments *</label>
                <textarea
                  value={selfReviewData.self_comments}
                  onChange={(e) => setSelfReviewData({ ...selfReviewData, self_comments: e.target.value })}
                  rows="4"
                  placeholder="Your overall comments about your performance..."
                  required
                />
              </div>

              <div className="form-actions">
                <button type="button" className="cancel-btn" onClick={() => setShowSelfReview(false)}>Cancel</button>
                <button type="submit" className="submit-btn">Submit Self Review</button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="reviews-grid">
        {reviews.map(review => (
          <div key={review.id} className="review-card">
            <div className="review-header">
              <div>
                <h3>{review.review_period}</h3>
                <p className="review-type">{review.review_type.replace('_', ' ')}</p>
              </div>
              <span className="status-badge" style={{ background: getStatusColor(review.status) }}>
                {review.status.replace('_', ' ')}
              </span>
            </div>

            <div className="review-content">
              {review.status === 'draft' && (
                <div className="action-section">
                  <p>Please complete your self review</p>
                  <button
                    className="primary-btn"
                    onClick={() => {
                      setSelectedReview(review);
                      setShowSelfReview(true);
                    }}
                  >
                    Start Self Review
                  </button>
                </div>
              )}

              {review.self_rating && (
                <div className="rating-section">
                  <h4>Self Rating</h4>
                  <div className="rating-display">
                    <span className="rating-value">{review.self_rating}</span>
                    <span className="rating-stars">{getRatingStars(review.self_rating)}</span>
                  </div>
                  {review.achievements && (
                    <div className="review-text">
                      <strong>Achievements:</strong>
                      <p>{review.achievements}</p>
                    </div>
                  )}
                </div>
              )}

              {review.manager_rating && (
                <div className="rating-section">
                  <h4>Manager Rating</h4>
                  <div className="rating-display">
                    <span className="rating-value">{review.manager_rating}</span>
                    <span className="rating-stars">{getRatingStars(review.manager_rating)}</span>
                  </div>
                  <p><strong>Manager:</strong> {review.manager_name}</p>
                  {review.manager_comments && (
                    <div className="review-text">
                      <strong>Comments:</strong>
                      <p>{review.manager_comments}</p>
                    </div>
                  )}
                  {review.promotion_recommendation && (
                    <p className="promotion-badge">🎉 Recommended for Promotion</p>
                  )}
                  {review.salary_revision_percentage && (
                    <p className="salary-badge">💰 Salary Revision: {review.salary_revision_percentage}%</p>
                  )}
                </div>
              )}

              {review.final_rating && (
                <div className="final-rating">
                  <h4>Final Rating</h4>
                  <div className="rating-display">
                    <span className="rating-value">{review.final_rating}</span>
                    <span className="rating-stars">{getRatingStars(review.final_rating)}</span>
                  </div>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {reviews.length === 0 && (
        <div className="empty-state">
          <p>No performance reviews available</p>
        </div>
      )}
    </div>
  );
};

export default PerformanceReviews;
