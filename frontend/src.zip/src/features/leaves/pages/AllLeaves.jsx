import { useState, useEffect } from "react";
import api from "@/services/api/client";
import { formatDate } from "@/utils/dateFormatter";
import "../../employees/pages/EmployeesData.css";

export default function AllLeaves() {
  const [leaves, setLeaves] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filterStatus, setFilterStatus] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    fetchAllLeaves();
  }, []);

  const fetchAllLeaves = async () => {
    try {
      setLoading(true);
      const response = await api.get("/leaves");
      setLeaves(response.data || []);
    } catch (err) {
      console.error("Error fetching leaves:", err);
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status) => {
    const styles = {
      pending: { background: "#fed7aa", color: "#9a3412", padding: "4px 12px", borderRadius: "12px", fontSize: "12px", fontWeight: "600" },
      approved: { background: "#bbf7d0", color: "#166534", padding: "4px 12px", borderRadius: "12px", fontSize: "12px", fontWeight: "600" },
      rejected: { background: "#fecaca", color: "#991b1b", padding: "4px 12px", borderRadius: "12px", fontSize: "12px", fontWeight: "600" }
    };
    return <span style={styles[status]}>{status.toUpperCase()}</span>;
  };

  const filteredLeaves = leaves.filter(leave => {
    const matchesStatus = filterStatus === "all" || leave.status === filterStatus;
    const matchesSearch = 
      leave.first_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      leave.last_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      leave.department?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      leave.leave_type?.toLowerCase().includes(searchTerm.toLowerCase());
    
    return matchesStatus && matchesSearch;
  });

  const stats = {
    total: leaves.length,
    pending: leaves.filter(l => l.status === 'pending').length,
    approved: leaves.filter(l => l.status === 'approved').length,
    rejected: leaves.filter(l => l.status === 'rejected').length
  };

  if (loading) {
    return (
      <div className="employees-page">
        <h1>All Leaves</h1>
        <div style={{ textAlign: "center", padding: "50px" }}>Loading...</div>
      </div>
    );
  }

  return (
    <div className="employees-page">
      <h1 style={{ marginBottom: "20px" }}>All Leave Applications</h1>

      <div className="dashboard-grid" style={{ gridTemplateColumns: "repeat(4, 1fr)", marginBottom: "20px" }}>
        <div className="widget">
          <h3>Total Requests</h3>
          <div style={{ fontSize: "32px", fontWeight: "bold", color: "#0284c7" }}>{stats.total}</div>
        </div>
        <div className="widget">
          <h3>Pending</h3>
          <div style={{ fontSize: "32px", fontWeight: "bold", color: "#ea580c" }}>{stats.pending}</div>
        </div>
        <div className="widget">
          <h3>Approved</h3>
          <div style={{ fontSize: "32px", fontWeight: "bold", color: "#16a34a" }}>{stats.approved}</div>
        </div>
        <div className="widget">
          <h3>Rejected</h3>
          <div style={{ fontSize: "32px", fontWeight: "bold", color: "#dc2626" }}>{stats.rejected}</div>
        </div>
      </div>

      <div className="employees-header" style={{ marginBottom: "20px" }}>
        <input
          type="text"
          className="search-box"
          placeholder="Search by employee, department, or leave type..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          style={{ flex: 1 }}
        />
        <select
          className="filter"
          value={filterStatus}
          onChange={(e) => setFilterStatus(e.target.value)}
        >
          <option value="all">All Status</option>
          <option value="pending">Pending</option>
          <option value="approved">Approved</option>
          <option value="rejected">Rejected</option>
        </select>
      </div>

      <div className="widget">
        {filteredLeaves.length === 0 ? (
          <div style={{ textAlign: "center", padding: "50px", color: "#9ca3af" }}>
            📭 No leave applications found
          </div>
        ) : (
          <table className="employees-table">
            <thead>
              <tr>
                <th>Employee</th>
                <th>Department</th>
                <th>Leave Type</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Days</th>
                <th>Reason</th>
                <th>Status</th>
                <th>Manager Comment</th>
                <th>Applied On</th>
              </tr>
            </thead>
            <tbody>
              {filteredLeaves.map((leave) => (
                <tr key={leave.id}>
                  <td>{leave.first_name} {leave.last_name}</td>
                  <td>{leave.department}</td>
                  <td>{leave.leave_type}</td>
                  <td>{formatDate(leave.start_date)}</td>
                  <td>{formatDate(leave.end_date)}</td>
                  <td>{leave.days}</td>
                  <td style={{ maxWidth: "200px" }}>{leave.reason}</td>
                  <td>{getStatusBadge(leave.status)}</td>
                  <td style={{ maxWidth: "200px" }}>{leave.manager_comment || "-"}</td>
                  <td>{formatDate(leave.created_at)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
