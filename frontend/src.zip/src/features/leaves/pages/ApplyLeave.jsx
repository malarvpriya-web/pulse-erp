import { useState } from "react";
import api from "@/services/api/client";
import "../../employees/pages/EmployeesData.css";

export default function ApplyLeave() {
  const [leaveType, setLeaveType] = useState("Sick Leave");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [days, setDays] = useState(0);
  const [reason, setReason] = useState("");
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  const leaveTypes = [
    "Sick Leave",
    "Casual Leave",
    "Earned Leave",
    "Maternity Leave",
    "Paternity Leave",
    "Unpaid Leave",
    "Compensatory Off"
  ];

  const calculateDays = (start, end) => {
    if (!start || !end) return 0;
    const startD = new Date(start);
    const endD = new Date(end);
    const diffTime = Math.abs(endD - startD);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;
    return diffDays;
  };

  const handleStartDateChange = (e) => {
    const start = e.target.value;
    setStartDate(start);
    if (endDate) {
      setDays(calculateDays(start, endDate));
    }
  };

  const handleEndDateChange = (e) => {
    const end = e.target.value;
    setEndDate(end);
    if (startDate) {
      setDays(calculateDays(startDate, end));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!startDate || !endDate || !reason) {
      setMessage("Please fill all fields");
      return;
    }

    if (new Date(endDate) < new Date(startDate)) {
      setMessage("End date cannot be before start date");
      return;
    }

    setLoading(true);
    setMessage("");

    try {
      await api.post("/leaves", {
        leave_type: leaveType,
        start_date: startDate,
        end_date: endDate,
        days: days,
        reason: reason
      });

      setMessage("✅ Leave application submitted successfully!");
      
      setLeaveType("Sick Leave");
      setStartDate("");
      setEndDate("");
      setDays(0);
      setReason("");
    } catch (err) {
      console.error(err);
      setMessage("❌ " + (err.response?.data?.error || "Failed to submit leave application"));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="employees-page">
      <h1 style={{ marginBottom: "20px" }}>Apply for Leave</h1>

      <div className="widget" style={{ maxWidth: "800px", padding: "30px" }}>
        <form onSubmit={handleSubmit}>
          <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
            <div>
              <label style={{ fontSize: "14px", fontWeight: "600", marginBottom: "8px", display: "block" }}>
                Leave Type
              </label>
              <select
                className="filter"
                value={leaveType}
                onChange={(e) => setLeaveType(e.target.value)}
                style={{ width: "100%", fontSize: "14px" }}
              >
                {leaveTypes.map((type) => (
                  <option key={type} value={type}>{type}</option>
                ))}
              </select>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "15px" }}>
              <div>
                <label style={{ fontSize: "14px", fontWeight: "600", marginBottom: "8px", display: "block" }}>
                  Start Date
                </label>
                <input
                  type="date"
                  className="search-box"
                  value={startDate}
                  onChange={handleStartDateChange}
                  style={{ width: "100%", fontSize: "14px" }}
                  required
                />
              </div>

              <div>
                <label style={{ fontSize: "14px", fontWeight: "600", marginBottom: "8px", display: "block" }}>
                  End Date
                </label>
                <input
                  type="date"
                  className="search-box"
                  value={endDate}
                  onChange={handleEndDateChange}
                  style={{ width: "100%", fontSize: "14px" }}
                  required
                />
              </div>

              <div>
                <label style={{ fontSize: "14px", fontWeight: "600", marginBottom: "8px", display: "block" }}>
                  Total Days
                </label>
                <input
                  type="number"
                  className="search-box"
                  value={days}
                  readOnly
                  style={{ width: "100%", fontSize: "14px", background: "#f3f4f6" }}
                />
              </div>
            </div>

            <div>
              <label style={{ fontSize: "14px", fontWeight: "600", marginBottom: "8px", display: "block" }}>
                Reason
              </label>
              <textarea
                className="search-box"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                rows="4"
                placeholder="Enter reason for leave..."
                style={{ width: "100%", resize: "vertical", fontFamily: "inherit", fontSize: "14px" }}
                required
              />
            </div>

            <button
              type="submit"
              className="primary-btn"
              disabled={loading}
              style={{ width: "200px", fontSize: "14px" }}
            >
              {loading ? "Submitting..." : "Submit Leave Request"}
            </button>

            {message && (
              <div style={{
                padding: "12px",
                borderRadius: "6px",
                background: message.includes("✅") ? "#d1fae5" : "#fee2e2",
                color: message.includes("✅") ? "#065f46" : "#991b1b",
                fontSize: "14px"
              }}>
                {message}
              </div>
            )}
          </div>
        </form>
      </div>
    </div>
  );
}
