import { useState, useEffect } from "react";
import api from "@/services/api/client";
import { formatDate } from "@/utils/dateFormatter";
import "../../employees/pages/EmployeesData.css";

export default function TeamLeaves() {
  const [leaves, setLeaves] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedLeave, setSelectedLeave] = useState(null);
  const [managerComment, setManagerComment] = useState("");
  const [actionLoading, setActionLoading] = useState(false);

  useEffect(() => {
    fetchTeamLeaves();
  }, []);

  const fetchTeamLeaves = async () => {
    try {
      setLoading(true);
      const response = await api.get("/leaves/team");
      setLeaves(response.data || []);
    } catch (err) {
      console.error("Error fetching team leaves:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async (leaveId) => {
    if (!confirm("Approve this leave request?")) return;
    
    setActionLoading(true);
    try {
      await api.patch(`/leaves/${leaveId}/approve`, {
        manager_comment: managerComment
      });
      setManagerComment("");
      setSelectedLeave(null);
      fetchTeamLeaves();
    } catch (err) {
      alert("Error approving leave: " + (err.response?.data?.error || err.message));
    } finally {
      setActionLoading(false);
    }
  };

  const handleReject = async (leaveId) => {
    if (!managerComment.trim()) {
      alert("Please provide a reason for rejection");
      return;
    }
    
    if (!confirm("Reject this leave request?")) return;
    
    setActionLoading(true);
    try {
      await api.patch(`/leaves/${leaveId}/reject`, {
        manager_comment: managerComment
      });
      setManagerComment("");
      setSelectedLeave(null);
      fetchTeamLeaves();
    } catch (err) {
      alert("Error rejecting leave: " + (err.response?.data?.error || err.message));
    } finally {
      setActionLoading(false);
    }
  };

  const getStatusBadge = (status) => {
    const styles = {
      pending: { background: "#fed7aa", color: "#9a3412", padding: "4px 12px", borderRadius: "12px", fontSize: "12px", fontWeight: "600" },
      approved: { background: "#bbf7d0", color: "#166534", padding: "4px 12px", borderRadius: "12px", fontSize: "12px", fontWeight: "600" },
      rejected: { background: "#fecaca", color: "#991b1b", padding: "4px 12px", borderRadius: "12px", fontSize: "12px", fontWeight: "600" }
    };
    return <span style={styles[status]}>{status.toUpperCase()}</span>;
  };

  if (loading) {
    return (
      <div className="employees-page">
        <h1>Team Leaves</h1>
        <div style={{ textAlign: "center", padding: "50px" }}>Loading...</div>
      </div>
    );
  }

  return (
    <div className="employees-page">
      <h1 style={{ marginBottom: "20px" }}>Team Leave Requests</h1>

      <div className="widget">
        {leaves.length === 0 ? (
          <div style={{ textAlign: "center", padding: "50px", color: "#9ca3af" }}>
            📭 No team leave requests found
          </div>
        ) : (
          <table className="employees-table">
            <thead>
              <tr>
                <th>Employee</th>
                <th>Department</th>
                <th>Leave Type</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Days</th>
                <th>Reason</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {leaves.map((leave) => (
                <tr key={leave.id}>
                  <td>{leave.first_name} {leave.last_name}</td>
                  <td>{leave.department}</td>
                  <td>{leave.leave_type}</td>
                  <td>{formatDate(leave.start_date)}</td>
                  <td>{formatDate(leave.end_date)}</td>
                  <td>{leave.days}</td>
                  <td style={{ maxWidth: "200px" }}>{leave.reason}</td>
                  <td>{getStatusBadge(leave.status)}</td>
                  <td>
                    {leave.status === 'pending' ? (
                      <div style={{ display: "flex", gap: "8px" }}>
                        <button
                          className="primary-btn"
                          onClick={() => setSelectedLeave(leave)}
                          style={{ padding: "6px 12px", fontSize: "12px" }}
                        >
                          Review
                        </button>
                      </div>
                    ) : (
                      <span style={{ fontSize: "12px", color: "#9ca3af" }}>
                        {leave.manager_comment || "No comment"}
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {selectedLeave && (
        <div style={{
          position: "fixed",
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: "rgba(0,0,0,0.5)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          zIndex: 1000
        }}>
          <div style={{
            background: "white",
            padding: "30px",
            borderRadius: "12px",
            maxWidth: "600px",
            width: "90%"
          }}>
            <h2 style={{ marginBottom: "20px" }}>Review Leave Request</h2>
            
            <div style={{ marginBottom: "20px" }}>
              <p><strong>Employee:</strong> {selectedLeave.first_name} {selectedLeave.last_name}</p>
              <p><strong>Leave Type:</strong> {selectedLeave.leave_type}</p>
              <p><strong>Duration:</strong> {formatDate(selectedLeave.start_date)} to {formatDate(selectedLeave.end_date)} ({selectedLeave.days} days)</p>
              <p><strong>Reason:</strong> {selectedLeave.reason}</p>
            </div>

            <div style={{ marginBottom: "20px" }}>
              <label style={{ fontSize: "14px", fontWeight: "600", marginBottom: "8px", display: "block" }}>
                Manager Comment (Optional for approval, Required for rejection)
              </label>
              <textarea
                className="search-box"
                value={managerComment}
                onChange={(e) => setManagerComment(e.target.value)}
                rows="3"
                placeholder="Add your comment..."
                style={{ width: "100%", resize: "vertical", fontFamily: "inherit", fontSize: "14px" }}
              />
            </div>

            <div style={{ display: "flex", gap: "10px", justifyContent: "flex-end" }}>
              <button
                className="primary-btn"
                onClick={() => {
                  setSelectedLeave(null);
                  setManagerComment("");
                }}
                style={{ background: "#6b7280" }}
                disabled={actionLoading}
              >
                Cancel
              </button>
              <button
                className="primary-btn"
                onClick={() => handleReject(selectedLeave.id)}
                style={{ background: "#dc2626" }}
                disabled={actionLoading}
              >
                {actionLoading ? "Processing..." : "Reject"}
              </button>
              <button
                className="primary-btn"
                onClick={() => handleApprove(selectedLeave.id)}
                style={{ background: "#16a34a" }}
                disabled={actionLoading}
              >
                {actionLoading ? "Processing..." : "Approve"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
