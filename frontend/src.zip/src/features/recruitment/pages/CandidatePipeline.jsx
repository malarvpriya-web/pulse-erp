import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams, useNavigate } from 'react-router-dom';
import './Recruitment.css';

const CandidatePipeline = () => {
  const { jobId } = useParams();
  const navigate = useNavigate();
  const [candidates, setCandidates] = useState([]);
  const [openings, setOpenings] = useState([]);
  const [selectedJob, setSelectedJob] = useState(jobId || '');
  const [showForm, setShowForm] = useState(false);
  const [selectedCandidate, setSelectedCandidate] = useState(null);
  const [formData, setFormData] = useState({
    full_name: '',
    email: '',
    phone: '',
    source: 'manual',
    applied_job_id: ''
  });

  useEffect(() => {
    fetchOpenings();
  }, []);

  useEffect(() => {
    if (selectedJob) {
      fetchCandidates();
    }
  }, [selectedJob]);

  const fetchOpenings = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await axios.get('http://localhost:5000/api/recruitment/openings?status=open', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setOpenings(res.data);
      if (!selectedJob && res.data.length > 0) {
        setSelectedJob(res.data[0].id);
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const fetchCandidates = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await axios.get(`http://localhost:5000/api/recruitment/candidates?applied_job_id=${selectedJob}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setCandidates(res.data);
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token');
      await axios.post('http://localhost:5000/api/recruitment/candidates',
        { ...formData, applied_job_id: selectedJob },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      alert('Candidate added successfully');
      setShowForm(false);
      resetForm();
      fetchCandidates();
    } catch (error) {
      alert('Error adding candidate');
    }
  };

  const moveStage = async (candidateId, newStage) => {
    try {
      const token = localStorage.getItem('token');
      const currentUser = JSON.parse(localStorage.getItem('user') || '{}');
      await axios.post(`http://localhost:5000/api/recruitment/candidates/${candidateId}/move-stage`,
        { new_stage: newStage, moved_by: currentUser.id, notes: `Moved to ${newStage}` },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      fetchCandidates();
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const resetForm = () => {
    setFormData({
      full_name: '',
      email: '',
      phone: '',
      source: 'manual',
      applied_job_id: ''
    });
  };

  const stages = [
    { key: 'applied', title: 'Applied', color: '#dbeafe' },
    { key: 'screening', title: 'Screening', color: '#fef3c7' },
    { key: 'hr_round', title: 'HR Round', color: '#fed7aa' },
    { key: 'technical_round', title: 'Technical', color: '#e0e7ff' },
    { key: 'final_round', title: 'Final Round', color: '#fce7f3' },
    { key: 'offer', title: 'Offer', color: '#dcfce7' },
    { key: 'hired', title: 'Hired', color: '#d1fae5' }
  ];

  const groupedCandidates = stages.reduce((acc, stage) => {
    acc[stage.key] = candidates.filter(c => c.current_stage === stage.key && c.overall_status === 'active');
    return acc;
  }, {});

  const rejectedCandidates = candidates.filter(c => c.overall_status === 'rejected');

  return (
    <div className="recruitment-page">
      <div className="page-header">
        <div>
          <button className="back-btn" onClick={() => navigate('/recruitment/openings')}>← Back</button>
          <h1>Candidate Pipeline</h1>
        </div>
        <div className="header-actions">
          <select
            value={selectedJob}
            onChange={(e) => setSelectedJob(e.target.value)}
            className="job-select"
          >
            {openings.map(o => (
              <option key={o.id} value={o.id}>{o.job_title} - {o.department}</option>
            ))}
          </select>
          <button className="primary-btn" onClick={() => setShowForm(true)}>+ Add Candidate</button>
        </div>
      </div>

      {showForm && (
        <div className="modal-overlay">
          <div className="modal-content">
            <h2>Add Candidate</h2>
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label>Full Name *</label>
                <input
                  type="text"
                  value={formData.full_name}
                  onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
                  required
                />
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Email *</label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    required
                  />
                </div>
                <div className="form-group">
                  <label>Phone</label>
                  <input
                    type="text"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  />
                </div>
              </div>

              <div className="form-group">
                <label>Source</label>
                <select
                  value={formData.source}
                  onChange={(e) => setFormData({ ...formData, source: e.target.value })}
                >
                  <option value="manual">Manual</option>
                  <option value="website">Website</option>
                  <option value="linkedin">LinkedIn</option>
                  <option value="referral">Referral</option>
                  <option value="job_portal">Job Portal</option>
                  <option value="campus">Campus</option>
                </select>
              </div>

              <div className="form-actions">
                <button type="button" className="cancel-btn" onClick={() => { setShowForm(false); resetForm(); }}>Cancel</button>
                <button type="submit" className="submit-btn">Add Candidate</button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="kanban-board">
        {stages.map(stage => (
          <div key={stage.key} className="kanban-column">
            <div className="column-header" style={{ background: stage.color }}>
              <h3>{stage.title}</h3>
              <span className="count-badge">{groupedCandidates[stage.key]?.length || 0}</span>
            </div>
            <div className="column-content">
              {groupedCandidates[stage.key]?.map(candidate => (
                <div 
                  key={candidate.id} 
                  className="candidate-card"
                  onClick={() => navigate(`/recruitment/candidates/${candidate.id}`)}
                >
                  <h4>{candidate.full_name}</h4>
                  <p className="candidate-email">{candidate.email}</p>
                  <p className="candidate-phone">{candidate.phone}</p>
                  <div className="candidate-source">
                    <span className="source-badge">{candidate.source}</span>
                  </div>
                  <select
                    value={candidate.current_stage}
                    onChange={(e) => {
                      e.stopPropagation();
                      moveStage(candidate.id, e.target.value);
                    }}
                    className="stage-select"
                    onClick={(e) => e.stopPropagation()}
                  >
                    {stages.map(s => (
                      <option key={s.key} value={s.key}>{s.title}</option>
                    ))}
                    <option value="rejected">Rejected</option>
                  </select>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {rejectedCandidates.length > 0 && (
        <div className="section">
          <h2>Rejected Candidates ({rejectedCandidates.length})</h2>
          <div className="rejected-list">
            {rejectedCandidates.map(candidate => (
              <div key={candidate.id} className="rejected-card">
                <strong>{candidate.full_name}</strong>
                <span>{candidate.email}</span>
                <span className="rejected-badge">Rejected</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default CandidatePipeline;
