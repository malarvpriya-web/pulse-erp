import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './Recruitment.css';

const JobOpenings = () => {
  const navigate = useNavigate();
  const [openings, setOpenings] = useState([]);
  const [requisitions, setRequisitions] = useState([]);
  const [showReqForm, setShowReqForm] = useState(false);
  const [showOpeningForm, setShowOpeningForm] = useState(false);
  const [selectedRequisition, setSelectedRequisition] = useState(null);
  const [filter, setFilter] = useState('all');
  const [formData, setFormData] = useState({
    job_title: '',
    department_id: '',
    employment_type: 'full_time',
    number_of_positions: '',
    job_description: '',
    skills_required: '',
    experience_required: '',
    location: '',
    salary_range: ''
  });
  const [openingData, setOpeningData] = useState({
    requisition_id: '',
    opening_date: new Date().toISOString().split('T')[0],
    closing_date: ''
  });

  useEffect(() => {
    fetchOpenings();
    fetchRequisitions();
  }, [filter]);

  const fetchOpenings = async () => {
    try {
      const token = localStorage.getItem('token');
      const url = filter === 'all' 
        ? 'http://localhost:5000/api/recruitment/openings'
        : `http://localhost:5000/api/recruitment/openings?status=${filter}`;
      const res = await axios.get(url, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setOpenings(res.data);
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const fetchRequisitions = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await axios.get('http://localhost:5000/api/recruitment/requisitions', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setRequisitions(res.data);
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const handleSubmitRequisition = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token');
      const currentUser = JSON.parse(localStorage.getItem('user') || '{}');
      await axios.post('http://localhost:5000/api/recruitment/requisitions',
        { ...formData, requested_by_employee_id: currentUser.id },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      alert('Job requisition created successfully');
      setShowReqForm(false);
      resetForm();
      fetchRequisitions();
    } catch (error) {
      alert('Error creating requisition');
    }
  };

  const handleCreateOpening = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token');
      await axios.post('http://localhost:5000/api/recruitment/openings',
        openingData,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      alert('Job opening created successfully');
      setShowOpeningForm(false);
      setOpeningData({ requisition_id: '', opening_date: new Date().toISOString().split('T')[0], closing_date: '' });
      fetchOpenings();
      fetchRequisitions();
    } catch (error) {
      alert('Error creating opening');
    }
  };

  const handleApproveRequisition = async (id) => {
    try {
      const token = localStorage.getItem('token');
      await axios.put(`http://localhost:5000/api/recruitment/requisitions/${id}`,
        { status: 'approved' },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      alert('Requisition approved');
      fetchRequisitions();
    } catch (error) {
      alert('Error approving requisition');
    }
  };

  const openCreateOpening = (requisition) => {
    setSelectedRequisition(requisition);
    setOpeningData({ ...openingData, requisition_id: requisition.id });
    setShowOpeningForm(true);
  };

  const resetForm = () => {
    setFormData({
      job_title: '',
      department_id: '',
      employment_type: 'full_time',
      number_of_positions: '',
      job_description: '',
      skills_required: '',
      experience_required: '',
      location: '',
      salary_range: ''
    });
  };

  const getStatusColor = (status) => {
    const colors = {
      draft: '#f3f4f6',
      pending_approval: '#fef3c7',
      approved: '#dbeafe',
      open: '#dcfce7',
      paused: '#fed7aa',
      closed: '#fee2e2'
    };
    return colors[status] || '#f3f4f6';
  };

  return (
    <div className="recruitment-page">
      <div className="page-header">
        <h1>Job Openings & Requisitions</h1>
        <button className="primary-btn" onClick={() => setShowReqForm(true)}>+ New Requisition</button>
      </div>

      {showReqForm && (
        <div className="modal-overlay">
          <div className="modal-content">
            <h2>Create Job Requisition</h2>
            <form onSubmit={handleSubmitRequisition}>
              <div className="form-row">
                <div className="form-group">
                  <label>Job Title *</label>
                  <input
                    type="text"
                    value={formData.job_title}
                    onChange={(e) => setFormData({ ...formData, job_title: e.target.value })}
                    required
                  />
                </div>
                <div className="form-group">
                  <label>Department</label>
                  <input
                    type="text"
                    value={formData.department_id}
                    onChange={(e) => setFormData({ ...formData, department_id: e.target.value })}
                  />
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Employment Type</label>
                  <select
                    value={formData.employment_type}
                    onChange={(e) => setFormData({ ...formData, employment_type: e.target.value })}
                  >
                    <option value="full_time">Full Time</option>
                    <option value="contract">Contract</option>
                    <option value="intern">Intern</option>
                    <option value="part_time">Part Time</option>
                  </select>
                </div>
                <div className="form-group">
                  <label>Number of Positions *</label>
                  <input
                    type="number"
                    value={formData.number_of_positions}
                    onChange={(e) => setFormData({ ...formData, number_of_positions: e.target.value })}
                    required
                  />
                </div>
              </div>

              <div className="form-group">
                <label>Job Description</label>
                <textarea
                  value={formData.job_description}
                  onChange={(e) => setFormData({ ...formData, job_description: e.target.value })}
                  rows="4"
                />
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Skills Required</label>
                  <input
                    type="text"
                    value={formData.skills_required}
                    onChange={(e) => setFormData({ ...formData, skills_required: e.target.value })}
                    placeholder="e.g., React, Node.js, SQL"
                  />
                </div>
                <div className="form-group">
                  <label>Experience Required</label>
                  <input
                    type="text"
                    value={formData.experience_required}
                    onChange={(e) => setFormData({ ...formData, experience_required: e.target.value })}
                    placeholder="e.g., 3-5 years"
                  />
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Location</label>
                  <input
                    type="text"
                    value={formData.location}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                  />
                </div>
                <div className="form-group">
                  <label>Salary Range</label>
                  <input
                    type="text"
                    value={formData.salary_range}
                    onChange={(e) => setFormData({ ...formData, salary_range: e.target.value })}
                    placeholder="e.g., $60k - $80k"
                  />
                </div>
              </div>

              <div className="form-actions">
                <button type="button" className="cancel-btn" onClick={() => { setShowReqForm(false); resetForm(); }}>Cancel</button>
                <button type="submit" className="submit-btn">Create Requisition</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {showOpeningForm && (
        <div className="modal-overlay">
          <div className="modal-content">
            <h2>Create Job Opening</h2>
            <p><strong>Job:</strong> {selectedRequisition?.job_title}</p>
            <form onSubmit={handleCreateOpening}>
              <div className="form-row">
                <div className="form-group">
                  <label>Opening Date *</label>
                  <input
                    type="date"
                    value={openingData.opening_date}
                    onChange={(e) => setOpeningData({ ...openingData, opening_date: e.target.value })}
                    required
                  />
                </div>
                <div className="form-group">
                  <label>Closing Date</label>
                  <input
                    type="date"
                    value={openingData.closing_date}
                    onChange={(e) => setOpeningData({ ...openingData, closing_date: e.target.value })}
                  />
                </div>
              </div>

              <div className="form-actions">
                <button type="button" className="cancel-btn" onClick={() => setShowOpeningForm(false)}>Cancel</button>
                <button type="submit" className="submit-btn">Create Opening</button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="section">
        <div className="section-header">
          <h2>Active Job Openings</h2>
          <div className="filter-group">
            <select value={filter} onChange={(e) => setFilter(e.target.value)} className="filter-select">
              <option value="all">All</option>
              <option value="open">Open</option>
              <option value="paused">Paused</option>
              <option value="closed">Closed</option>
            </select>
          </div>
        </div>
        <div className="table-container">
          <table className="data-table">
            <thead>
              <tr>
                <th>Job Title</th>
                <th>Department</th>
                <th>Type</th>
                <th>Location</th>
                <th>Positions</th>
                <th>Filled</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {openings.map(opening => (
                <tr key={opening.id}>
                  <td><strong>{opening.job_title}</strong></td>
                  <td>{opening.department}</td>
                  <td><span className="badge">{opening.employment_type?.replace('_', ' ')}</span></td>
                  <td>{opening.location}</td>
                  <td>{opening.number_of_positions}</td>
                  <td>{opening.positions_filled}</td>
                  <td>
                    <span className="status-badge" style={{ background: getStatusColor(opening.status) }}>
                      {opening.status}
                    </span>
                  </td>
                  <td>
                    <button 
                      className="action-btn"
                      onClick={() => navigate(`/recruitment/pipeline/${opening.id}`)}
                    >
                      View Pipeline
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="section">
        <h2>Job Requisitions</h2>
        <div className="table-container">
          <table className="data-table">
            <thead>
              <tr>
                <th>Job Title</th>
                <th>Department</th>
                <th>Positions</th>
                <th>Requested By</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {requisitions.map(req => (
                <tr key={req.id}>
                  <td><strong>{req.job_title}</strong></td>
                  <td>{req.department}</td>
                  <td>{req.number_of_positions}</td>
                  <td>{req.requested_by_name}</td>
                  <td>
                    <span className="status-badge" style={{ background: getStatusColor(req.status) }}>
                      {req.status.replace('_', ' ')}
                    </span>
                  </td>
                  <td>
                    {req.status === 'draft' && (
                      <button className="action-btn" onClick={() => handleApproveRequisition(req.id)}>
                        Approve
                      </button>
                    )}
                    {req.status === 'approved' && (
                      <button className="action-btn" onClick={() => openCreateOpening(req)}>
                        Create Opening
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default JobOpenings;
