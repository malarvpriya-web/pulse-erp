import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './Recruitment.css';

const RecruitmentDashboard = () => {
  const navigate = useNavigate();
  const [dashboard, setDashboard] = useState(null);
  const [sourceAnalytics, setSourceAnalytics] = useState([]);
  const [timeToHire, setTimeToHire] = useState(null);
  const [offerRate, setOfferRate] = useState(null);
  const [interviewRatio, setInterviewRatio] = useState(null);

  useEffect(() => {
    fetchDashboard();
    fetchSourceAnalytics();
    fetchTimeToHire();
    fetchOfferRate();
    fetchInterviewRatio();
  }, []);

  const fetchDashboard = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await axios.get('http://localhost:5000/api/recruitment/dashboard', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setDashboard(res.data);
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const fetchSourceAnalytics = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await axios.get('http://localhost:5000/api/recruitment/analytics/source', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setSourceAnalytics(res.data);
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const fetchTimeToHire = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await axios.get('http://localhost:5000/api/recruitment/analytics/time-to-hire', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setTimeToHire(res.data);
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const fetchOfferRate = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await axios.get('http://localhost:5000/api/recruitment/analytics/offer-acceptance-rate', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setOfferRate(res.data);
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const fetchInterviewRatio = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await axios.get('http://localhost:5000/api/recruitment/analytics/interview-to-hire-ratio', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setInterviewRatio(res.data);
    } catch (error) {
      console.error('Error:', error);
    }
  };

  if (!dashboard) return <div>Loading...</div>;

  const maxSourceCount = Math.max(...sourceAnalytics.map(s => parseInt(s.count)), 1);

  return (
    <div className="recruitment-page">
      <div className="page-header">
        <h1>Recruitment Dashboard</h1>
        <div className="header-actions">
          <button className="action-btn" onClick={() => navigate('/recruitment/openings')}>Job Openings</button>
          <button className="action-btn" onClick={() => navigate('/recruitment/candidates')}>All Candidates</button>
        </div>
      </div>

      <div className="metrics-grid">
        <div className="metric-card">
          <div className="metric-icon" style={{ background: '#dcfce7' }}>📋</div>
          <div className="metric-content">
            <h3>Open Positions</h3>
            <p className="metric-value">{dashboard.open_positions}</p>
          </div>
        </div>

        <div className="metric-card">
          <div className="metric-icon" style={{ background: '#dbeafe' }}>👥</div>
          <div className="metric-content">
            <h3>Active Candidates</h3>
            <p className="metric-value">{dashboard.active_candidates}</p>
          </div>
        </div>

        <div className="metric-card">
          <div className="metric-icon" style={{ background: '#fef3c7' }}>📅</div>
          <div className="metric-content">
            <h3>Interviews Scheduled</h3>
            <p className="metric-value">{dashboard.interviews_scheduled}</p>
          </div>
        </div>

        <div className="metric-card">
          <div className="metric-icon" style={{ background: '#e0e7ff' }}>📝</div>
          <div className="metric-content">
            <h3>Offers Pending</h3>
            <p className="metric-value">{dashboard.offers_pending}</p>
          </div>
        </div>

        <div className="metric-card">
          <div className="metric-icon" style={{ background: '#d1fae5' }}>✅</div>
          <div className="metric-content">
            <h3>Offers Accepted</h3>
            <p className="metric-value">{dashboard.offers_accepted}</p>
          </div>
        </div>

        <div className="metric-card">
          <div className="metric-icon" style={{ background: '#fce7f3' }}>📊</div>
          <div className="metric-content">
            <h3>Total Candidates</h3>
            <p className="metric-value">{dashboard.total_candidates}</p>
          </div>
        </div>
      </div>

      <div className="analytics-grid">
        <div className="analytics-card">
          <h3>Hiring Source Analytics</h3>
          <div className="chart-container">
            {sourceAnalytics.map(source => (
              <div key={source.source} className="bar-item">
                <div className="bar-label">{source.source}</div>
                <div className="bar-wrapper">
                  <div 
                    className="bar-fill" 
                    style={{ 
                      width: `${(parseInt(source.count) / maxSourceCount) * 100}%`,
                      background: '#0284c7'
                    }}
                  >
                    <span className="bar-value">{source.count}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="analytics-card">
          <h3>Key Metrics</h3>
          <div className="metrics-list">
            {timeToHire && (
              <div className="metric-item">
                <span className="metric-label">Average Time to Hire</span>
                <span className="metric-stat">{Math.round(timeToHire.avg_days || 0)} days</span>
              </div>
            )}
            {offerRate && (
              <div className="metric-item">
                <span className="metric-label">Offer Acceptance Rate</span>
                <span className="metric-stat">{offerRate.rate}%</span>
              </div>
            )}
            {interviewRatio && (
              <div className="metric-item">
                <span className="metric-label">Interview to Hire Ratio</span>
                <span className="metric-stat">{interviewRatio.ratio}%</span>
              </div>
            )}
            <div className="metric-item">
              <span className="metric-label">Active Pipeline</span>
              <span className="metric-stat">{dashboard.active_candidates} candidates</span>
            </div>
          </div>
        </div>
      </div>

      <div className="section">
        <h2>Quick Actions</h2>
        <div className="action-grid">
          <div className="action-card" onClick={() => navigate('/recruitment/openings')}>
            <h4>📋 Manage Job Openings</h4>
            <p>Create and manage job requisitions and openings</p>
          </div>
          <div className="action-card" onClick={() => navigate('/recruitment/candidates')}>
            <h4>👥 View All Candidates</h4>
            <p>Browse and manage candidate database</p>
          </div>
          <div className="action-card" onClick={() => navigate('/recruitment/interviews')}>
            <h4>📅 Interview Schedule</h4>
            <p>View and manage interview schedules</p>
          </div>
          <div className="action-card" onClick={() => navigate('/recruitment/email-templates')}>
            <h4>📧 Email Templates</h4>
            <p>Manage recruitment email templates</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RecruitmentDashboard;
