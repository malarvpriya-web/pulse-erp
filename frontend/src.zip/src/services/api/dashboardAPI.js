const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';
//import { dashboardAPI } from "../services/api/dashboardAPI";
export const dashboardAPI = {
  getManagementDashboard: async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/dashboard/management`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch management dashboard');
      }
      
      return await response.json();
    } catch (error) {
      console.error('Management dashboard fetch error:', error);
      return getMockManagementDashboard();
    }
  },

  getDashboardData: async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/dashboard/data`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch dashboard data');
      }
      
      return await response.json();
    } catch (error) {
      console.error('Dashboard data fetch error:', error);
      return getMockDashboardData();
    }
  },

  getDashboardInsights: async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/dashboard/insights`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch insights');
      }
      
      return await response.json();
    } catch (error) {
      console.error('Insights fetch error:', error);
      return getMockInsights();
    }
  },

  getRevenueTrend: async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/dashboard/revenue`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch revenue data');
      }
      
      return await response.json();
    } catch (error) {
      console.error('Revenue data fetch error:', error);
      return getMockRevenueData();
    }
  },

  getExpenseBreakdown: async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/dashboard/expenses`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch expense data');
      }
      
      return await response.json();
    } catch (error) {
      console.error('Expense data fetch error:', error);
      return getMockExpenseData();
    }
  }
};

const getMockManagementDashboard = () => ({
  insights: {
    revenueToday: 240000,
    invoicesDue: 14,
    openTickets: 6,
    stockAlerts: 3
  },
  kpi: {
    revenue: { total: 4200000, trend: 12 },
    projects: { active: 24, trend: 8 },
    employees: { total: 150, trend: 3 },
    approvals: { pending: 8, trend: -15 }
  },
  revenueTrend: [
    { month: 'Jan', revenue: 65000 },
    { month: 'Feb', revenue: 72000 },
    { month: 'Mar', revenue: 68000 },
    { month: 'Apr', revenue: 78000 },
    { month: 'May', revenue: 85000 },
    { month: 'Jun', revenue: 90000 }
  ],
  expenseBreakdown: [
    { name: 'Salaries', value: 45000 },
    { name: 'Operations', value: 25000 },
    { name: 'Marketing', value: 15000 },
    { name: 'Infrastructure', value: 10000 },
    { name: 'Other', value: 5000 }
  ],
  cashPosition: {
    balance: 250000,
    inflow: 12000,
    outflow: 8500
  },
  workforce: {
    total: 150,
    newHires: 5,
    attrition: 2,
    attendanceRate: 94
  },
  operations: {
    openTickets: 12,
    activeProjects: 8,
    overdueTasks: 5,
    lowStockAlerts: 3
  },
  alerts: {
    alerts: [
      { severity: 'critical', message: 'Server CPU usage high', module: 'Infrastructure', time: '10m ago' },
      { severity: 'warning', message: 'Low inventory alert', module: 'Inventory', time: '1h ago' },
      { severity: 'info', message: 'Backup completed', module: 'System', time: '2h ago' }
    ]
  },
  salesPipeline: {
    openDeals: 24,
    wonDeals: 8,
    lostDeals: 2,
    winRate: 80
  },
  approvals: {
    items: [
      { type: 'Leave Request', requester: 'John Doe', date: '2 hours ago' },
      { type: 'Purchase Order', requester: 'Jane Smith', date: '5 hours ago' },
      { type: 'Expense Claim', requester: 'Bob Johnson', date: '1 day ago' }
    ]
  },
  tasks: {
    tasks: [
      { title: 'Review Q4 Budget', project: 'Finance', priority: 'high', dueDate: 'Today' },
      { title: 'Approve Leave Requests', project: 'HR', priority: 'medium', dueDate: 'Tomorrow' },
      { title: 'Update Sales Report', project: 'Sales', priority: 'high', dueDate: 'Today' },
      { title: 'Team Meeting Prep', project: 'Management', priority: 'low', dueDate: 'Friday' }
    ]
  },
  activity: {
    activities: [
      { type: 'user', action: 'New employee onboarded', user: 'HR Team', time: '10m ago', icon: '✓' },
      { type: 'document', action: 'Invoice #1234 generated', user: 'Finance', time: '25m ago', icon: '✓' },
      { type: 'payment', action: 'Payment received', user: 'Accounts', time: '1h ago', icon: '✓' },
      { type: 'task', action: 'Project milestone completed', user: 'Dev Team', time: '2h ago', icon: '✓' },
      { type: 'user', action: 'Leave request approved', user: 'Manager', time: '3h ago', icon: '✓' },
      { type: 'document', action: 'Contract signed', user: 'Sales', time: '5h ago', icon: '✓' },
      { type: 'task', action: 'Bug fix deployed', user: 'Dev Team', time: '26h ago', icon: '✓' },
      { type: 'payment', action: 'Vendor payment processed', user: 'Accounts', time: '30h ago', icon: '✓' },
      { type: 'user', action: 'Training session completed', user: 'HR Team', time: '50h ago', icon: '✓' },
      { type: 'document', action: 'Report submitted', user: 'Analytics', time: '3d ago', icon: '✓' },
      { type: 'task', action: 'Sprint planning completed', user: 'Dev Team', time: '5d ago', icon: '✓' }
    ]
  }
});

const getMockDashboardData = () => ({
  kpis: {
    revenue: { total: 450000, trend: 8 },
    projects: { active: 24, trend: 12 },
    employees: { total: 150, trend: 3 },
    approvals: { pending: 8, trend: -15 }
  },
  revenueTrend: [
    { month: 'Jan', revenue: 65000 },
    { month: 'Feb', revenue: 72000 },
    { month: 'Mar', revenue: 68000 },
    { month: 'Apr', revenue: 78000 },
    { month: 'May', revenue: 85000 },
    { month: 'Jun', revenue: 90000 }
  ],
  expenseBreakdown: [
    { name: 'Salaries', value: 45000 },
    { name: 'Operations', value: 25000 },
    { name: 'Marketing', value: 15000 },
    { name: 'Infrastructure', value: 10000 },
    { name: 'Other', value: 5000 }
  ],
  cashPosition: {
    balance: 250000,
    inflow: 12000,
    outflow: 8500,
    upcomingPayments: 45000
  },
  workforce: {
    total: 150,
    newHires: 5,
    attrition: 2,
    attendanceRate: 94
  },
  operations: {
    openTickets: 12,
    activeProjects: 8,
    overdueTasks: 5,
    lowStockAlerts: 3
  },
  salesPipeline: {
    openDeals: 24,
    wonDeals: 8,
    lostDeals: 2,
    winRate: 80
  },
  alerts: {
    alerts: [
      { severity: 'critical', message: 'Server CPU usage high', module: 'Infrastructure', time: '10m ago' },
      { severity: 'warning', message: 'Low inventory alert', module: 'Inventory', time: '1h ago' },
      { severity: 'info', message: 'Backup completed', module: 'System', time: '2h ago' }
    ]
  },
  approvalsQueue: {
    items: [
      { type: 'Leave Request', requester: 'John Doe', date: '2 hours ago' },
      { type: 'Purchase Order', requester: 'Jane Smith', date: '5 hours ago' },
      { type: 'Expense Claim', requester: 'Bob Johnson', date: '1 day ago' }
    ]
  },
  tasks: {
    tasks: [
      { title: 'Review Q4 Budget', project: 'Finance', priority: 'high', dueDate: 'Today' },
      { title: 'Approve Leave Requests', project: 'HR', priority: 'medium', dueDate: 'Tomorrow' },
      { title: 'Update Sales Report', project: 'Sales', priority: 'high', dueDate: 'Today' },
      { title: 'Team Meeting Prep', project: 'Management', priority: 'low', dueDate: 'Friday' }
    ]
  },
  recentActivity: {
    activities: [
      { type: 'user', action: 'New employee onboarded', user: 'HR Team', time: '10m ago', icon: '✓' },
      { type: 'document', action: 'Invoice #1234 generated', user: 'Finance', time: '25m ago', icon: '✓' },
      { type: 'payment', action: 'Payment received', user: 'Accounts', time: '1h ago', icon: '✓' },
      { type: 'task', action: 'Project milestone completed', user: 'Dev Team', time: '2h ago', icon: '✓' },
      { type: 'user', action: 'Leave request approved', user: 'Manager', time: '3h ago', icon: '✓' },
      { type: 'document', action: 'Contract signed', user: 'Sales', time: '5h ago', icon: '✓' },
      { type: 'task', action: 'Bug fix deployed', user: 'Dev Team', time: '26h ago', icon: '✓' },
      { type: 'payment', action: 'Vendor payment processed', user: 'Accounts', time: '30h ago', icon: '✓' },
      { type: 'user', action: 'Training session completed', user: 'HR Team', time: '50h ago', icon: '✓' },
      { type: 'document', action: 'Report submitted', user: 'Analytics', time: '3d ago', icon: '✓' },
      { type: 'task', action: 'Sprint planning completed', user: 'Dev Team', time: '5d ago', icon: '✓' }
    ]
  }
});

const getMockInsights = () => ({
  revenueToday: 240000,
  invoicesDue: 14,
  openTickets: 6,
  stockAlerts: 3
});

const getMockRevenueData = () => [
  { month: 'Jan', revenue: 65000 },
  { month: 'Feb', revenue: 72000 },
  { month: 'Mar', revenue: 68000 },
  { month: 'Apr', revenue: 78000 },
  { month: 'May', revenue: 85000 },
  { month: 'Jun', revenue: 90000 }
];

const getMockExpenseData = () => [
  { name: 'Salaries', value: 45000 },
  { name: 'Operations', value: 25000 },
  { name: 'Marketing', value: 15000 },
  { name: 'Infrastructure', value: 10000 },
  { name: 'Other', value: 5000 }
];

export default dashboardAPI;
