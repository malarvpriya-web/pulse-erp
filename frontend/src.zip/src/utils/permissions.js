export const hasPermission = (module, action) => {
  const permissions = JSON.parse(localStorage.getItem("permissions") || "[]");
  const modulePermission = permissions.find(p => p.module === module);
  
  if (!modulePermission) return false;
  
  const actionMap = {
    view: "can_view",
    add: "can_add",
    edit: "can_edit",
    delete: "can_delete",
    approve: "can_approve",
    export: "can_export"
  };
  
  return modulePermission[actionMap[action]] === true;
};

export const getVisibleModules = () => {
  const permissions = JSON.parse(localStorage.getItem("permissions") || "[]");
  return permissions.filter(p => p.can_view).map(p => p.module);
};
