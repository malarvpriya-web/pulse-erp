import { useState, useEffect } from "react";
import Layout from "./components/Layout";
import Login from "./pages/Login";
import Unauthorized from "./pages/Unauthorized";

function App() {
  const [page, setPage] = useState("Home");
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [initializing, setInitializing] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem("token");
    const user = localStorage.getItem("user");
    const role = localStorage.getItem("role");
    
    if (token && user && role) {
      setIsLoggedIn(true);
      
      const userData = JSON.parse(user);
      const roleRedirects = {
        employee: "Home",
        manager: "ERPDashboard",
        department_head: "ERPDashboard",
        admin: "ERPDashboard",
        super_admin: "ERPDashboard"
      };
      setPage(roleRedirects[userData.role] || "Home");
    }
    setInitializing(false);
  }, []);

  if (initializing) {
    return <div style={{ padding: "50px", textAlign: "center" }}>Loading...</div>;
  }

  if (!isLoggedIn) {
    return <Login setIsLoggedIn={setIsLoggedIn} setPage={setPage} />;
  }

  return (
    <Layout 
      page={page} 
      setPage={setPage}
      selectedEmployee={selectedEmployee}
      setSelectedEmployee={setSelectedEmployee}
    />
  );
}

export default App;