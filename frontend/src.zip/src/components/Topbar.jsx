import "./Topbar.css";
import logo from "../assets/logo.png";

export default function Topbar() {
  const user = JSON.parse(localStorage.getItem("user") || "{}");
  const role = localStorage.getItem("role") || "employee";

  const getUserDisplayName = () => {
    if (user.name) return user.name;
    if (user.email) {
      const emailPrefix = user.email.split('@')[0];
      return emailPrefix.charAt(0).toUpperCase() + emailPrefix.slice(1);
    }
    return "User";
  };

  const getRoleLabel = (role) => {
    const roleMap = {
      super_admin: "Super Administrator",
      admin: "Administrator",
      manager: "Manager",
      department_head: "Department Head",
      employee: "Employee"
    };
    return roleMap[role] || "Employee";
  };

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    localStorage.removeItem("role");
    localStorage.removeItem("permissions");
    window.location.href = "/";
  };
  
  return (
    <div className="topbar">
      <div className="brand-center">
        <img src={logo} className="top-logo" alt="Logo" />
        <h1 className="brand-title">Manifest Technologies</h1>
      </div>

      <div style={{ display: "flex", alignItems: "center", gap: "20px" }}>
        <div style={{ textAlign: "right" }}>
          <div style={{ fontSize: "18px", fontWeight: "600", color: "#111827" }}>
            Welcome back, {getUserDisplayName()}
          </div>
          
        </div>
        
        <button className="logout-btn" onClick={handleLogout}>
          Logout
        </button>
      </div>
    </div>
  );
}