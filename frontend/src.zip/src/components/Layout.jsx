import React from 'react';
import Sidebar, { MENU_ITEMS } from "./Sidebar";
import ERPDashboard from "@/pages/ERPDashboard"
import Topbar from "./Topbar";
import { hasPermission } from "../utils/permissions";
import Parties from "@/features/finance/pages/Parties";
import FinanceReports from "@/features/finance/pages/Reports";
import PaymentBatch from "@/features/finance/pages/PaymentBatch";
import Tickets from "@/features/finance/pages/Tickets";
import FinancialRatios from "@/features/finance/pages/FinancialRatios";
import PurchaseRequestDashboard from "@/features/procurement/pages/PurchaseRequest";
import PurchaseOrderManagement from "@/features/procurement/pages/PurchaseOrderManagement";
import StockSummary from "@/features/inventory/pages/StockSummary";
import Projects from "@/features/projects/pages/Projects";
import KanbanBoard from "@/features/projects/pages/KanbanBoard";
import Timesheets from "@/features/timesheets/pages/Timesheets";
import PerformanceReviews from "@/features/performance/pages/PerformanceReviews";
import SalesDashboard from "@/features/crm/pages/SalesDashboard";
import Leads from "@/features/crm/pages/Leads";
import Accounts from "@/features/crm/pages/Accounts";
import Contacts from "@/features/crm/pages/Contacts";
import OpportunitiesKanban from "@/features/crm/pages/OpportunitiesKanban";
import Quotations from "@/features/sales/pages/Quotations";
import Campaigns from "@/features/marketing/pages/Campaigns";
import Reports from "@/features/reports/pages/Reports";
import NotificationCenter from "@/features/notifications/pages/NotificationCenter";
import OrgChart from "@/features/orgchart/pages/OrgChart";
import SalesPlaybooks from "@/features/sales/pages/SalesPlaybooks";
import SalesCalendar from "@/features/sales/pages/SalesCalendar";
import SalesDocuments from "@/features/sales/pages/SalesDocuments";
import Subscriptions from "@/features/sales/pages/Subscriptions";
import SalesPartners from "@/features/sales/pages/SalesPartners";
import "./Layout.css";
import Home from "@/pages/Home";
import Unauthorized from "@/pages/Unauthorized";
import SuperAdminDashboard from "../pages/SuperAdminDashboard";
import EmployeesDashboard from "@/features/employees/pages/EmployeesDashboard";
import EmployeesData from "@/features/employees/pages/EmployeesData";
import ExEmployees from "@/features/employees/pages/ExEmployees";
import EmployeeProfile from "@/features/employees/pages/EmployeeProfile";
import AddEmployee from "@/features/employees/pages/AddEmployee";
import EditEmployee from "@/features/employees/pages/EditEmployee";

import Announcements from "@/features/hr/pages/Announcements";
import Probation from "@/features/hr/pages/Probation";
import Notifications from "@/features/notifications/pages/Notifications";

import LeaveApplication from "@/features/leaves/pages/LeaveApplication";
import LeaveManagement from "@/features/leaves/pages/LeaveManagement";
import ApplyLeave from "@/features/leaves/pages/ApplyLeave";
import MyLeaves from "@/features/leaves/pages/MyLeaves";
import TeamLeaves from "@/features/leaves/pages/TeamLeaves";
import AllLeaves from "@/features/leaves/pages/AllLeaves";
import LeaveManagementNew from "@/features/leaves/pages/LeaveManagement";
import LeaveSettings from "@/features/leaves/pages/LeaveSettings";

import HolidayCalendar from "@/features/hr/pages/HolidayCalendar";
import Policies from "@/features/hr/pages/Policies";
import Downloads from "@/features/hr/pages/Downloads";

import ApprovalCenter from "@/features/approvals/pages/ApprovalCenter";

import AttendanceDashboard from "@/features/attendance/pages/AttendanceDashboard";


export default function Layout({ page, setPage, selectedEmployee, setSelectedEmployee }) {
  const userRole = localStorage.getItem('role') || 'employee';
  
  const pageModuleMap = {
    "EmployeesDashboard": "employees",
    "EmployeesData": "employees",
    "ExEmployees": "employees",
    "EmployeeProfile": "employees",
    "AddEmployee": "employees",
    "EditEmployee": "employees",
    "FinanceDashboardNew": "finance",
    "CFODashboard": "finance",
    "ChartOfAccounts": "finance",
    "InvoicesNew": "finance",
    "SupplierBills": "finance",
    "JournalEntry": "finance",
    "PeriodClosing": "finance",
    "Parties": "finance",
    "FinanceReports": "finance",
    "PaymentBatch": "finance",
    "FinancialRatios": "finance",
    "Projects": "projects",
    "KanbanBoard": "projects",
    "Reports": "reports",
    "StockSummary": "inventory",
    "Announcements": "announcements",
    "Policies": "policies",
    "Downloads": "downloads",
    "LeaveApplication": "leave",
    "LeaveManagement": "leave",
    "LeaveManagementNew": "leave",
    "LeaveSettings": "leave",
    "ApplyLeave": "leave",
    "MyLeaves": "leave",
    "TeamLeaves": "leave",
    "AllLeaves": "leave",
    "TravelDashboard": "travel",
    "TravelRequests": "travel",
    "TravelCalendar": "travel",
    "TravelBookings": "travel",
    "TravelAdvances": "travel",
    "TravelExpenses": "travel",
    "TravelApprovals": "travel",
    "TravelAnalytics": "travel",
    "SupportDashboard": "service",
    "AllTickets": "service",
    "MyTickets": "service",
    "TicketDetail": "service",
    "AgentWorkload": "service",
    "ServiceEngineers": "service",
    "FieldVisitScheduler": "service",
    "KnowledgeBase": "service",
    "ServiceContracts": "service"
  };
  
  const hasAccess = (pageName) => {
    if (userRole === 'super_admin' || userRole === 'admin') return true;
    
    const moduleName = pageModuleMap[pageName];
    if (moduleName) {
      return hasPermission(moduleName, "view");
    }
    
    return true;
  };

  const renderPage = () => {
    if (!hasAccess(page)) {
      return <Unauthorized setPage={setPage} />;
    }
    if (page === "Home") return <Home />;
    if (page === "ERPDashboard") return <ERPDashboard />;
    if (page === "SuperAdminDashboard") return <SuperAdminDashboard />;
    if (page === "EmployeesDashboard") return <EmployeesDashboard setPage={setPage} setSelectedEmployee={setSelectedEmployee} />;
    if (page === "EmployeesData") return <EmployeesData setPage={setPage} setSelectedEmployee={setSelectedEmployee} />;
    if (page === "ExEmployees") return <ExEmployees setPage={setPage} setSelectedEmployee={setSelectedEmployee} />;
    if (page === "EmployeeProfile") return <EmployeeProfile employee={selectedEmployee} setPage={setPage} />;
    if (page === "AddEmployee") return <AddEmployee setPage={setPage} employee={selectedEmployee} setSelectedEmployee={setSelectedEmployee} />;
    if (page === "EditEmployee") return <EditEmployee employee={selectedEmployee} setPage={setPage} />;
    if (page === "Announcements") return <Announcements />;
    if (page === "Probation") return <Probation />;
    if (page === "Notifications") return <Notifications />;
    if (page === "LeaveApplication") return <LeaveApplication />;
    if (page === "LeaveManagement") return <LeaveManagement />;
    if (page === "ApplyLeave") return <ApplyLeave />;
    if (page === "MyLeaves") return <MyLeaves />;
    if (page === "TeamLeaves") return <TeamLeaves />;
    if (page === "AllLeaves") return <AllLeaves />;
    if (page === "HolidayCalendar") return <HolidayCalendar />;
    if (page === "Policies") return <Policies />;
    if (page === "Downloads") return <Downloads />;
    if (page === "Parties") return <Parties />;
    if (page === "FinanceReports") return <FinanceReports />;
    if (page === "PaymentBatch") return <PaymentBatch />;
    if (page === "Tickets") return <Tickets />;
    if (page === "FinancialRatios") return <FinancialRatios />;
    if (page === "PurchaseRequestDashboard") return <PurchaseRequestDashboard />;
    if (page === "PurchaseOrderManagement") return <PurchaseOrderManagement />;
    // if (page === "GoodsReceipt") return <GoodsReceipt />;
    if (page === "StockSummary") return <StockSummary />;
    if (page === "Projects") return <Projects />;
    if (page === "KanbanBoard") return <KanbanBoard />;
    if (page === "Timesheets") return <Timesheets />;
    if (page === "PerformanceReviews") return <PerformanceReviews />;
    if (page === "RecruitmentDashboard") return <RecruitmentDashboard />;
    if (page === "JobRequisitionPipeline") return <JobRequisitionPipeline />;
    if (page === "JobOpenings") return <JobOpenings />;
    if (page === "CandidatePipeline") return <CandidatePipeline />;
    if (page === "InterviewScheduler") return <InterviewScheduler />;
    if (page === "OfferManagement") return <OfferManagement />;
    if (page === "ResumeDatabase") return <ResumeDatabase />;
    if (page === "TalentPools") return <TalentPools />;
    if (page === "RecruiterDashboard") return <RecruiterDashboard />;
    if (page === "HiringForecasts") return <HiringForecasts />;
    if (page === "InterviewQuestionBank") return <InterviewQuestionBank />;
    if (page === "RecruitmentAgencies") return <RecruitmentAgencies />;
    if (page === "SalesDashboard") return <SalesDashboard />;
    if (page === "Leads") return <Leads />;
    if (page === "Accounts") return <Accounts />;
    if (page === "Contacts") return <Contacts />;
    if (page === "OpportunitiesKanban") return <OpportunitiesKanban />;
    if (page === "Quotations") return <Quotations />;
    if (page === "Campaigns") return <Campaigns />;
    if (page === "Reports") return <Reports />;
    if (page === "NotificationCenter") return <NotificationCenter />;
    if (page === "OrgChart") return <OrgChart />;
    if (page === "AuditLogs") return <AuditLogs />;
    if (page === "AttendanceDashboard") return <AttendanceDashboard />;
    if (page === "LeaveManagementNew") return <LeaveManagementNew />;
    if (page === "LeaveSettings") return <LeaveSettings />;
    if (page === "ERPDashboard") return <ERPDashboard />;
    if (page === "ApprovalCenter") return <ApprovalCenter />;
    if (page === "FinanceDashboardNew") return <FinanceDashboardNew />;
    if (page === "ChartOfAccounts") return <ChartOfAccounts />;
    if (page === "InvoicesNew") return <Invoices />;
    if (page === "SupplierBills") return <SupplierBills />;
    if (page === "JournalEntry") return <JournalEntry />;
    if (page === "PeriodClosing") return <PeriodClosing />;
    if (page === "CFODashboard") return <CFODashboard />;
    if (page === "SalesForecasts") return <SalesForecasts />;
    if (page === "SalesPlaybooks") return <SalesPlaybooks />;
    if (page === "SalesCalendar") return <SalesCalendar />;
    if (page === "SalesDocuments") return <SalesDocuments />;
    if (page === "Subscriptions") return <Subscriptions />;
    if (page === "SalesPartners") return <SalesPartners />;
    if (page === "Territories") return <Territories />;
    if (page === "Competitors") return <Competitors />;
    if (page === "SupportDashboard") return <SupportDashboard />;
    if (page === "AllTickets") return <AllTickets setPage={setPage} />;
    if (page === "TicketDetail") return <TicketDetail />;
    if (page === "AgentWorkload") return <AgentWorkload />;
    if (page === "ServiceEngineers") return <ServiceEngineers />;
    if (page === "FieldVisitScheduler") return <FieldVisitScheduler />;
    if (page === "KnowledgeBase") return <KnowledgeBase />;
    if (page === "ServiceContracts") return <ServiceContracts />;
    if (page === "TravelDashboard") return <TravelDashboard />;
    if (page === "TravelRequests") return <TravelRequests />;
    if (page === "TravelCalendar") return <TravelCalendar />;
    if (page === "TravelBookings") return <TravelBookings />;
    if (page === "TravelAdvances") return <TravelAdvances />;
    if (page === "TravelExpenses") return <TravelExpenses />;
    if (page === "TravelApprovals") return <TravelApprovals />;
    if (page === "TravelAnalytics") return <TravelAnalytics />;
    if (page === "WorkflowConfiguration") return <WorkflowConfiguration />;
    if (page === "ProjectWorkflowTracker") return <ProjectWorkflowTracker />;
    if (page === "DepartmentWorkload") return <DepartmentWorkload />;
    if (page === "BottleneckAnalytics") return <BottleneckAnalytics />;
    // Placeholders for other service pages
    return <Home />;
  };

  return (
    <div className="layout">
      <Sidebar setPage={setPage} />
      <div className="main-content">
        <Topbar />
        <div className="page-content">
          {renderPage()}
        </div>
      </div>
    </div>
  );
}