import React, { useState, useEffect, useCallback } from 'react';
//import RGL, { WidthProvider } from 'react-grid-layout';
import { RefreshCw, RotateCcw } from 'lucide-react';
import { getWidget } from './widgetRegistry';
import { getDefaultLayout, getSavedLayout, saveLayout, resetLayout } from '../../config/dashboardLayouts';
import { dashboardAPI } from '../../services/api/dashboardAPI';
import InsightBar from './InsightBar';
import KPISummary from './KPISummary';
import 'react-grid-layout/css/styles.css';
import 'react-resizable/css/styles.css';
import './DashboardEngine.css';

//const ReactGridLayout = WidthProvider(RGL);

// Error Boundary for individual widgets
class WidgetErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    console.error('Widget error:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="widget-error-boundary">
          <p>Widget failed to load</p>
          <button onClick={() => this.setState({ hasError: false })}>Retry</button>
        </div>
      );
    }
    return this.props.children;
  }
}

const DashboardEngine = ({ role }) => {
  const [layout, setLayout] = useState([]);
  const [dashboardData, setDashboardData] = useState({});
  const [insightData, setInsightData] = useState({});
  const [loading, setLoading] = useState(true);
  const [refreshKey, setRefreshKey] = useState(0);
  const [lastRefresh, setLastRefresh] = useState(new Date());
  const [isDragging, setIsDragging] = useState(false);

  const fetchDashboardData = useCallback(async () => {
    try {
      const data = await dashboardAPI.getDashboardData();
      setDashboardData(data && typeof data === 'object' ? data : {});

      const insights = await dashboardAPI.getDashboardInsights();
      setInsightData(insights && typeof insights === 'object' ? insights : {});

      setLastRefresh(new Date());
    } catch (error) {
      console.error('Failed to fetch dashboard data:', error);
    }
  }, []);

  const initializeDashboard = useCallback(async () => {
    try {
      setLoading(true);
      
      const savedLayout = getSavedLayout(role);
      const defaultLayout = getDefaultLayout(role);
      setLayout(savedLayout || defaultLayout);

      await fetchDashboardData();
    } catch (error) {
      console.error('Dashboard initialization error:', error);
      setLayout(getDefaultLayout(role));
    } finally {
      setLoading(false);
    }
  }, [role, fetchDashboardData]);

  useEffect(() => {
    initializeDashboard();
  }, [initializeDashboard]);

  useEffect(() => {
    const interval = setInterval(() => {
      fetchDashboardData();
    }, 300000);

    return () => clearInterval(interval);
  }, [fetchDashboardData]);

  const handleRefresh = useCallback(() => {
    setRefreshKey(prev => prev + 1);
    fetchDashboardData();
  }, [fetchDashboardData]);

  const handleLayoutChange = useCallback((newLayout) => {
    if (!isDragging) return;
    
    setLayout(newLayout);
    saveLayout(role, newLayout);
  }, [role, isDragging]);

  const handleResetLayout = useCallback(() => {
    const defaultLayout = resetLayout(role);
    setLayout(defaultLayout);
  }, [role]);

  const formatTime = (date) => {
    return date.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 18) return 'Good afternoon';
    return 'Good evening';
  };

  const formatDate = () => {
    const date = new Date();
    const options = { day: '2-digit', month: 'long', year: 'numeric' };
    return date.toLocaleDateString('en-US', options);
  };

  const renderWidget = useCallback((layoutItem) => {
    const widgetConfig = getWidget(layoutItem.i);
    
    if (!widgetConfig) {
      return (
        <div key={layoutItem.i} className="dashboard-widget-container">
          <div className="widget-not-found">
            <p>Widget not found: {layoutItem.i}</p>
          </div>
        </div>
      );
    }

    const WidgetComponent = widgetConfig.component;
    const widgetData = dashboardData[layoutItem.i] || null;

    return (
      <div key={layoutItem.i} className="dashboard-widget-container">
        <div className="widget-drag-handle">
          <span className="widget-drag-icon">⋮⋮</span>
        </div>
        <WidgetErrorBoundary>
          <WidgetComponent 
            title={widgetConfig.title}
            data={widgetData}
            refreshKey={refreshKey}
          />
        </WidgetErrorBoundary>
      </div>
    );
  }, [dashboardData, refreshKey]);

  if (loading) {
    return (
      <div className="dashboard-loading">
        <div className="loading-spinner"></div>
        <p>Loading dashboard...</p>
      </div>
    );
  }

  return (
    <div className="dashboard-engine">
      <div className="dashboard-header">
        <div className="header-left">
          <h1 className="dashboard-greeting">{getGreeting()}</h1>
          <p className="dashboard-date">Today: {formatDate()}</p>
        </div>
        
        <div className="header-right">
          <div className="last-refresh">
            Last updated: {formatTime(lastRefresh)}
          </div>
          <button 
            className="dashboard-btn" 
            onClick={handleResetLayout}
            title="Reset Layout"
          >
            <RotateCcw size={16} />
            <span>Reset</span>
          </button>
          <button 
            className="dashboard-btn primary" 
            onClick={handleRefresh}
            title="Refresh Dashboard"
          >
            <RefreshCw size={16} />
            <span>Refresh</span>
          </button>
        </div>
      </div>

      <InsightBar data={insightData} />
      <KPISummary data={dashboardData?.kpis} />

      <ReactGridLayout
        className="dashboard-grid-layout"
        layout={layout}
        cols={12}
        rowHeight={60}
        isDraggable={true}
        isResizable={true}
        draggableHandle=".widget-drag-handle"
        onLayoutChange={handleLayoutChange}
        onDragStart={() => setIsDragging(true)}
        onDragStop={() => setIsDragging(false)}
        onResizeStart={() => setIsDragging(true)}
        onResizeStop={() => setIsDragging(false)}
        margin={[18, 18]}
        containerPadding={[0, 0]}
      >
        {layout.map(renderWidget)}
      </ReactGridLayout>

      {layout.length === 0 && (
        <div className="dashboard-empty">
          <p>No widgets available for your role.</p>
        </div>
      )}
    </div>
  );
};

export default DashboardEngine;
