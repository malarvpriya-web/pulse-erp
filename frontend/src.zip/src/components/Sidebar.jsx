import { useReducer, useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import "./Sidebar.css";
import { hasPermission } from "../utils/permissions";
import {
  FaHome, FaUsers, FaChartLine, FaBullhorn,
  FaProjectDiagram, FaBox, FaFileAlt, FaCog, FaClock, FaStar, FaHandshake, FaShoppingCart, FaBell, FaSitemap, FaHistory, FaCalendarCheck, FaUmbrellaBeach, FaBriefcase, FaHeadset, FaPlane, FaCogs
} from "react-icons/fa";

// navigation configuration kept outside the component for clarity and reuse
export const MENU_ITEMS = [
  { name: "Home", icon: <FaHome />, page: "Home" },
  { name: "SuperAdminDashboard", icon: <FaChartLine />, page: "SuperAdminDashboard" },
  { name: "Dashboard", icon: <FaChartLine />, page: "ERPDashboard" },
  { name: "Approvals", icon: <FaBell />, page: "ApprovalCenter" },
  {
    name: "Employees",
    icon: <FaUsers />,
    submenu: [
      { name: "Employees Dashboard", page: "EmployeesDashboard" },
      { name: "Employees Data", page: "EmployeesData" },
      { name: "Ex-Employees", page: "ExEmployees" }
    ]
  },
  {
    name: "HR",
    icon: <FaBullhorn />,
    submenu: [
      { name: "Announcements", page: "Announcements" },
      { name: "Probation", page: "Probation" },
      { name: "Notifications", page: "Notifications" },
      { name: "Leave Application", page: "LeaveApplication" },
      { name: "Leave Management", page: "LeaveManagementNew" },
      { name: "Holiday Calendar", page: "HolidayCalendar" },
      { name: "Policies", page: "Policies" }
    ]
  },
  { name: "Recruitment", icon: <FaBriefcase />, submenu: [
    { name: "Dashboard", page: "RecruitmentDashboard" },
    { name: "Requisition Pipeline", page: "JobRequisitionPipeline" },
    { name: "Job Openings", page: "JobOpenings" },
    { name: "Candidate Pipeline", page: "CandidatePipeline" },
    { name: "Hiring Forecasts", page: "HiringForecasts" },
    { name: "Interview Scheduler", page: "InterviewScheduler" },
    { name: "Offer Management", page: "OfferManagement" }
  ] },
  { name: "Talent", icon: <FaStar />, submenu: [
    { name: "Resume Database", page: "ResumeDatabase" },
    { name: "Talent Pools", page: "TalentPools" },
    { name: "Question Bank", page: "InterviewQuestionBank" },
    { name: "Agencies", page: "RecruitmentAgencies" },
    { name: "Recruiter Performance", page: "RecruiterDashboard" }
  ] },
  { name: "Attendance", icon: <FaCalendarCheck />, submenu: [
    { name: "My Attendance", page: "AttendanceDashboard" },
    { name: "Team Attendance", page: "TeamAttendance" },
    { name: "Late Arrivals", page: "LateArrivals" }
  ] },
  { name: "Leaves", icon: <FaUmbrellaBeach />, submenu: [
    { name: "Apply Leave", page: "LeaveManagementNew" },
    { name: "Leave Approvals", page: "LeaveApprovals" },
    { name: "Leave Calendar", page: "LeaveCalendar" },
    { name: "Leave Settings", page: "LeaveSettings" }
  ] },
  { name: "Finance", icon: <FaChartLine />, submenu: [
    { name: "Finance Dashboard", page: "FinanceDashboardNew" },
    { name: "CFO Dashboard", page: "CFODashboard" },
    { name: "Chart of Accounts", page: "ChartOfAccounts" },
    { name: "Journal Entry", page: "JournalEntry" },
    { name: "Period Closing", page: "PeriodClosing" },
    { name: "Customers & Suppliers", page: "Parties" },
    { name: "Invoices", page: "InvoicesNew" },
    { name: "Bills", page: "SupplierBills" },
    { name: "Payment Batches", page: "PaymentBatch" },
    { name: "Bank Accounts", page: "BankAccounts" },
    { name: "Financial Ratios", page: "FinancialRatios" },
    { name: "Reports", page: "FinanceReports" }
  ] },
  { name: "Service Desk", icon: <FaHeadset />, submenu: [
    { name: "Dashboard", page: "SupportDashboard" },
    { name: "All Tickets", page: "AllTickets" },
    { name: "My Tickets", page: "MyTickets" },
    { name: "Field Service", page: "FieldService" },
    { name: "Visit Scheduler", page: "FieldVisitScheduler" },
    { name: "Service Engineers", page: "ServiceEngineers" },
    { name: "Knowledge Base", page: "KnowledgeBase" },
    { name: "Contracts", page: "ServiceContracts" },
    { name: "Agent Workload", page: "AgentWorkload" }
  ] },
  { name: "Travel Desk", icon: <FaPlane />, submenu: [
    { name: "Dashboard", page: "TravelDashboard" },
    { name: "My Requests", page: "TravelRequests" },
    { name: "Travel Calendar", page: "TravelCalendar" },
    { name: "Bookings", page: "TravelBookings" },
    { name: "Advances", page: "TravelAdvances" },
    { name: "Expenses", page: "TravelExpenses" },
    { name: "Approvals", page: "TravelApprovals" },
    { name: "Analytics", page: "TravelAnalytics" }
  ] },
  { name: "CRM", icon: <FaHandshake />, submenu: [
    { name: "Dashboard", page: "SalesDashboard" },
    { name: "Leads", page: "Leads" },
    { name: "Accounts", page: "Accounts" },
    { name: "Contacts", page: "Contacts" },
    { name: "Opportunities", page: "OpportunitiesKanban" },
    { name: "Lead Activities", page: "LeadActivities" }
  ] },
  { name: "Sales", icon: <FaShoppingCart />, submenu: [
    { name: "Quotations", page: "Quotations" },
    { name: "Sales Orders", page: "SalesOrders" },
    { name: "Sales Targets", page: "SalesTargets" },
    { name: "Forecasts", page: "SalesForecasts" },
    { name: "Playbooks", page: "SalesPlaybooks" },
    { name: "Calendar", page: "SalesCalendar" },
    { name: "Documents", page: "SalesDocuments" },
    { name: "Subscriptions", page: "Subscriptions" },
    { name: "Partners", page: "SalesPartners" },
    { name: "Territories", page: "Territories" },
    { name: "Competitors", page: "Competitors" }
  ] },
  { name: "Marketing", icon: <FaBullhorn />, submenu: [
    { name: "Campaigns", page: "Campaigns" },
    { name: "Campaign Analytics", page: "CampaignAnalytics" }
  ] },
  { name: "Procurement", icon: <FaProjectDiagram />, submenu: [
    { name: "PR Dashboard", page: "PurchaseRequestDashboard" },
    { name: "PO Management", page: "PurchaseOrderManagement" },
    { name: "Goods Receipt", page: "GoodsReceipt" },
    // { name: "Local Purchase", page: "LocalPurchase" } // Page component not created yet
  ] },
  { name: "Inventory", icon: <FaBox />, submenu: [
    // { name: "Items Master", page: "ItemsMaster" }, // Page component not created yet
    { name: "Stock Summary", page: "StockSummary" },
    // { name: "RM Issues", page: "RMIssues" }, // Page component not created yet
    // { name: "Stock Transfers", page: "StockTransfers" }, // Page component not created yet
    // { name: "Stock Adjustments", page: "StockAdjustments" }, // Page component not created yet
    // { name: "Advanced Dashboard", page: "AdvancedInventoryDashboard" },
    // { name: "Batch Tracking", page: "BatchTracking" },
    // { name: "Reservations", page: "StockReservations" },
    // { name: "Alerts & Suggestions", page: "StockAlertsAndSuggestions" },
    // { name: "Consumption Analysis", page: "MaterialConsumption" }
  ] },
  { name: "Projects", icon: <FaProjectDiagram />, submenu: [
    { name: "Projects", page: "Projects" },
    { name: "Task Board", page: "KanbanBoard" },
    { name: "Project Costing", page: "ProjectCosting" }
  ] },
  { name: "Operations", icon: <FaCogs />, submenu: [
    { name: "Workflow Config", page: "WorkflowConfiguration" },
    { name: "Project Tracker", page: "ProjectWorkflowTracker" },
    { name: "Dept Workload", page: "DepartmentWorkload" },
    { name: "Bottlenecks", page: "BottleneckAnalytics" }
  ] },
  { name: "Timesheets", icon: <FaClock />, submenu: [
    { name: "My Timesheets", page: "Timesheets" },
    { name: "Timesheet Approvals", page: "TimesheetApprovals" },
    { name: "Utilization Report", page: "UtilizationReport" }
  ] },
  { name: "Performance", icon: <FaStar />, submenu: [
    { name: "My Reviews", page: "PerformanceReviews" },
    { name: "Goals & KPIs", page: "Goals" },
    { name: "Team Performance", page: "TeamPerformance" }
  ] },
  { name: "Reports", icon: <FaFileAlt />, submenu: [
    { name: "Report Builder", page: "Reports" },
    { name: "Saved Reports", page: "SavedReports" }
  ] },
  { name: "Notifications", icon: <FaBell />, page: "NotificationCenter" },
  { name: "Org Chart", icon: <FaSitemap />, page: "OrgChart" },
  { name: "Audit Logs", icon: <FaHistory />, page: "AuditLogs" },
  { name: "Settings", icon: <FaCog /> }
];

function sidebarReducer(state, action) {
  switch (action.type) {
    case "EXPAND":
      return { ...state, expanded: true };
    case "COLLAPSE":
      return { expanded: false, openMenu: null };
    case "TOGGLE_MENU":
      return {
        expanded: true,
        openMenu: state.openMenu === action.name ? null : action.name
      };
    case "OPEN_MENU":                 // used for hover, never closes on duplicate
      return { expanded: true, openMenu: action.name };
    default:
      return state;
  }
}

export default function Sidebar({ setPage }) {
  const [state, dispatch] = useReducer(sidebarReducer, {
    expanded: false,
    openMenu: null
  });

  const [panelVisible, setPanelVisible] = useState(false);
  const [panelTop, setPanelTop] = useState(0);
  const panelRef = useRef(null);
  const menuRefs = useRef({});

  const userRole = localStorage.getItem('role') || 'employee';

  const moduleMap = {
    "Employees": "employees",
    "Finance": "finance",
    "Projects": "projects",
    "Reports": "reports",
    "Inventory": "inventory",
    "Announcements": "announcements",
    "Policies": "policies",
    "Downloads": "downloads",
    "Leaves": "leave",
    "Travel Desk": "travel",
    "Service Desk": "service",
    "HR": "announcements"
  };

  const visibleMenuItems = MENU_ITEMS.filter(item => {
    if (userRole === 'super_admin') return true;
    
    if (item.name === 'Home') return true;
    
    if (userRole === 'admin') return true;

    const moduleName = moduleMap[item.name];
    if (moduleName && !hasPermission(moduleName, "view")) {
      return false;
    }

    if (userRole === 'manager' || userRole === 'department_head') {
      const managerModules = ['Home', 'Dashboard', 'Approvals', 'Employees', 'Attendance', 'Leaves', 'Recruitment', 'Performance', 'Projects', 'Reports', 'Settings'];
      return managerModules.includes(item.name);
    }
    
    if (userRole === 'employee') {
      const allowedModules = ['Home', 'Attendance', 'Leaves', 'Travel Desk', 'Service Desk', 'HR', 'Timesheets'];
      return allowedModules.includes(item.name);
    }

    return true;
  });

  // animate open/close and calculate panel position
  useEffect(() => {
    if (state.openMenu) {
      setPanelVisible(true);
      // calculate position of the hovered menu item
      const el = menuRefs.current[state.openMenu];
      if (el) {
        const rect = el.getBoundingClientRect();
        setPanelTop(rect.top);
      }
    } else {
      const t = setTimeout(() => setPanelVisible(false), 250);
      return () => clearTimeout(t);
    }
  }, [state.openMenu]);

  useEffect(() => {
    function handleClickOutside(e) {
      if (panelRef.current && !panelRef.current.contains(e.target)) {
        dispatch({ type: "TOGGLE_MENU", name: null });
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const sideWidth = state.expanded ? 220 : 70;

  const handlePanelLeave = (e) => {
    const sidebarEl = document.querySelector('.sidebar');
    if (sidebarEl && sidebarEl.contains(e.relatedTarget)) return;
    dispatch({ type: 'COLLAPSE' });
  };

  const submenuPanel =
    panelVisible && (
      <div
        ref={panelRef}
        className={`submenu-panel ${state.openMenu ? "panel--visible" : ""}`}
        style={{ 
          left: `${sideWidth}px`,
          top: `${panelTop}px`
        }}
        onMouseLeave={handlePanelLeave}
      >
        {state.openMenu && visibleMenuItems.find((m) => m.name === state.openMenu)?.submenu &&
          visibleMenuItems.find((m) => m.name === state.openMenu)
            .submenu.map((sub) => (
              <button
                key={sub.name}
                className="nav-item"
                onClick={() => {
                  setPage(sub.page);
                  dispatch({ type: "COLLAPSE" });
                }}
              >
                {sub.name}
              </button>
            ))}
      </div>
    );

  // helper to avoid closing when pointer moves into floating panel
  const handleSidebarLeave = (e) => {
    // Check if relatedTarget exists and is a valid Node
    if (e.relatedTarget && e.relatedTarget instanceof Node) {
      if (panelRef.current && panelRef.current.contains(e.relatedTarget)) {
        // entering the panel, keep submenu open
        return;
      }
    }
    dispatch({ type: "COLLAPSE" });
  };

  return (
    <>
      <div
        className={`sidebar ${state.expanded ? "expanded" : ""}`}
        onMouseEnter={() => dispatch({ type: "EXPAND" })}
        onMouseLeave={handleSidebarLeave}
      >
        <ul>
          {visibleMenuItems.map((item) => (
            <li
              key={item.name}
              ref={(el) => {
                if (el) menuRefs.current[item.name] = el;
              }}
              onMouseEnter={() => {
                if (item.submenu) {
                  dispatch({ type: "OPEN_MENU", name: item.name });
                }
              }}
            >
              <button
                className="nav-item"
                onClick={() => {
                  if (item.page) {
                    setPage(item.page);
                    dispatch({ type: "COLLAPSE" });
                  }
                }}
              >
                <span className="icon">{item.icon}</span>
                {state.expanded && <span className="label">{item.name}</span>}
              </button>
            </li>
          ))}
        </ul>
      </div>
      {createPortal(submenuPanel, document.body)}
    </>
  );
}