import { useEffect } from "react";

export default function ProtectedRoute({ children, allowedRoles = [] }) {
  useEffect(() => {
    const token = localStorage.getItem("token");
    const role = localStorage.getItem("role");

    if (!token) {
      window.location.href = "/";
      return;
    }

    if (allowedRoles.length > 0 && !allowedRoles.includes(role)) {
      window.location.href = "/unauthorized";
      return;
    }
  }, [allowedRoles]);

  const token = localStorage.getItem("token");
  if (!token) return null;

  return children;
}
