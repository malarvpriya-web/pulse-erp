import React, { useState, useEffect, useCallback } from 'react';
import { RefreshCw } from 'lucide-react';
import { dashboardAPI } from "../services/api/dashboardAPI";

// Import Components
import ManagementInsightBar from '../components/dashboard/ManagementInsightBar';
import ExecutiveKPICards from '../components/dashboard/ExecutiveKPICards';
import RevenueTrendChart from '../components/dashboard/widgets/RevenueTrendChart';
import ExpenseBreakdownChart from '../components/dashboard/widgets/ExpenseBreakdownChart';
import CashPositionCard from '../components/dashboard/widgets/CashPositionCard';
import WorkforceWidget from '../components/dashboard/widgets/WorkforceWidget';
import OperationsWidget from '../components/dashboard/widgets/OperationsWidget';
import SystemAlertsWidget from '../components/dashboard/widgets/SystemAlertsWidget';
import SalesPipelineWidget from '../components/dashboard/widgets/SalesPipelineWidget';
import ApprovalsQueueWidget from '../components/dashboard/widgets/ApprovalsQueueWidget';
import TasksWidget from '../components/dashboard/widgets/TasksWidget';
import RecentActivityWidget from '../components/dashboard/widgets/RecentActivityWidget';

import './SuperAdminDashboard.css';

const SuperAdminDashboard = () => {
  const [dashboardData, setDashboardData] = useState({});
  const [loading, setLoading] = useState(true);
  const [refreshKey, setRefreshKey] = useState(0);
  const [lastRefresh, setLastRefresh] = useState(new Date());

  const fetchDashboardData = useCallback(async () => {
    try {
      const data = await dashboardAPI.getManagementDashboard();
      setDashboardData(data && typeof data === 'object' ? data : {});
      setLastRefresh(new Date());
    } catch (error) {
      console.error('Failed to fetch dashboard data:', error);
    }
  }, []);

  useEffect(() => {
    const initDashboard = async () => {
      setLoading(true);
      await fetchDashboardData();
      setLoading(false);
    };
    
    initDashboard();
  }, [fetchDashboardData]);

  useEffect(() => {
    const interval = setInterval(() => {
      fetchDashboardData();
      setRefreshKey(prev => prev + 1);
    }, 300000); // 5 minutes

    return () => clearInterval(interval);
  }, [fetchDashboardData]);

  const handleRefresh = useCallback(() => {
    setRefreshKey(prev => prev + 1);
    fetchDashboardData();
  }, [fetchDashboardData]);

  const formatTime = (date) => {
    return date.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 18) return 'Good afternoon';
    return 'Good evening';
  };

  const formatDate = () => {
    const date = new Date();
    const options = { day: '2-digit', month: 'long', year: 'numeric' };
    return date.toLocaleDateString('en-US', options);
  };

  

  return (
    <div className="dashboard-container">
      {/* Dashboard Header */}
      <div className="dashboard-header">
        <div className="header-left">
          <h1 className="dashboard-greeting">{getGreeting()}</h1>
          <p className="dashboard-date">Today: {formatDate()}</p>
        </div>
        
        <div className="header-right">
          <div className="last-refresh">
            Last updated: {formatTime(lastRefresh)}
          </div>
          <button 
            className="refresh-btn" 
            onClick={handleRefresh}
            title="Refresh Dashboard"
          >
            <RefreshCw size={16} />
            <span>Refresh</span>
          </button>
        </div>
      </div>

      {/* SECTION 1 - Management Insight Bar */}
      <ManagementInsightBar data={dashboardData?.insights} />

      {/* SECTION 2 - Executive KPI Cards */}
      <ExecutiveKPICards data={dashboardData?.kpi} />

      {/* SECTION 3 - Business Analytics */}
      <div className="dashboard-section">
        <div className="dashboard-grid">
          <div className="dashboard-widget analytics-large">
            <RevenueTrendChart 
              title="Revenue Trend"
              data={dashboardData?.revenueTrend}
              refreshKey={refreshKey}
            />
          </div>
          <div className="dashboard-widget analytics-medium">
            <ExpenseBreakdownChart 
              title="Expense Breakdown"
              data={dashboardData?.expenseBreakdown}
              refreshKey={refreshKey}
            />
          </div>
        </div>
      </div>

      {/* SECTION 4 - Operations Monitoring */}
      <div className="dashboard-section">
        <div className="dashboard-grid">
          <div className="dashboard-widget operations-card">
            <CashPositionCard 
              title="Cash Position"
              data={dashboardData?.cashPosition}
            />
          </div>
          <div className="dashboard-widget operations-card">
            <WorkforceWidget 
              title="Workforce"
              data={dashboardData?.workforce}
            />
          </div>
          <div className="dashboard-widget operations-card">
            <OperationsWidget 
              title="Operations"
              data={dashboardData?.operations}
            />
          </div>
          <div className="dashboard-widget operations-card">
            <SystemAlertsWidget 
              title="System Alerts"
              data={dashboardData?.alerts}
            />
          </div>
        </div>
      </div>

      {/* SECTION 5 - Sales and Approvals */}
      <div className="dashboard-section">
        <div className="dashboard-grid">
          <div className="dashboard-widget sales-large">
            <SalesPipelineWidget 
              title="Sales Pipeline"
              data={dashboardData?.salesPipeline}
            />
          </div>
          <div className="dashboard-widget approvals-medium">
            <ApprovalsQueueWidget 
              title="Pending Approvals"
              data={dashboardData?.approvals}
            />
          </div>
        </div>
      </div>

      {/* SECTION 6 - Tasks and Activity */}
      <div className="dashboard-section">
        <div className="dashboard-grid">
          <div className="dashboard-widget activity-half">
            <TasksWidget 
              title="My Tasks"
              data={dashboardData?.tasks}
            />
          </div>
          <div className="dashboard-widget activity-half">
            <RecentActivityWidget 
              title="Recent Activity"
              data={dashboardData?.activity}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default SuperAdminDashboard;
