import { useState, useEffect } from "react";
import api from "@/services/api/client";
import { formatDate } from "@/utils/dateFormatter";
import "./Home.css";
import { FaBirthdayCake, FaCalendarCheck, FaBullhorn, FaFileAlt, FaDownload } from 'react-icons/fa';

export default function Home() {
  const [celebrations, setCelebrations] = useState([]);
  const [announcements, setAnnouncements] = useState([]);
  const [upcomingEvents, setUpcomingEvents] = useState([]);
  const [policies, setPolicies] = useState([]);
  const [downloads, setDownloads] = useState([]);
  const [holidays, setHolidays] = useState([]);
  const [kpis, setKpis] = useState({
    totalEmployees: 0,
    attendanceToday: 0,
    pendingApprovals: 0,
    openTasks: 0
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadAllData();
    fetchKPIs();
  }, []);

  const loadAllData = async () => {
    setLoading(true);
    try {
      await Promise.all([
        fetchAnnouncements(),
        fetchUpcomingEvents(),
        fetchCelebrations(),
        fetchPolicies(),
        fetchDownloads(),
        fetchHolidays()
      ]);
    } catch (err) {
      console.error("Error loading home data:", err);
    } finally {
      setLoading(false);
    }
  };

  const fetchAnnouncements = async () => {
    try {
      const response = await api.get("/home/announcements");
      setAnnouncements(response.data || []);
    } catch (err) {
      console.error("Error fetching announcements:", err);
      setAnnouncements([]);
    }
  };

  const fetchUpcomingEvents = async () => {
    try {
      const response = await api.get("/home/events/upcoming");
      setUpcomingEvents(response.data || []);
    } catch (err) {
      console.error("Error fetching events:", err);
      setUpcomingEvents([]);
    }
  };

  const fetchCelebrations = async () => {
    try {
      const response = await api.get("/home/celebrations");
      setCelebrations(response.data || []);
    } catch (err) {
      console.error("Error fetching celebrations:", err);
      setCelebrations([]);
    }
  };

  const fetchPolicies = async () => {
    try {
      const response = await api.get("/home/policies");
      setPolicies(response.data || []);
    } catch (err) {
      console.error("Error fetching policies:", err);
      setPolicies([]);
    }
  };

  const fetchDownloads = async () => {
    try {
      const response = await api.get("/home/resources");
      setDownloads(response.data || []);
    } catch (err) {
      console.error("Error fetching downloads:", err);
      setDownloads([]);
    }
  };

  const fetchHolidays = async () => {
    try {
      const response = await api.get("/home/holidays");
      setHolidays(response.data || []);
    } catch (err) {
      console.error("Error fetching holidays:", err);
      setHolidays([]);
    }
  };

  const fetchKPIs = async () => {
    try {
      // Mock KPI data - replace with actual API calls
      setKpis({
        totalEmployees: 42,
        attendanceToday: 95,
        pendingApprovals: 3,
        openTasks: 6
      });
    } catch (err) {
      console.error("Error fetching KPIs:", err);
    }
  };

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return "Good morning";
    if (hour < 18) return "Good afternoon";
    return "Good evening";
  };

  const getCelebrationIcon = (type) => {
    if (type === 'Birthday') return '🎂';
    if (type === 'Work Anniversary') return '🎉';
    return '🎊';
  };

  
  return (
    <div className="home-container">
      <div className="welcome-card">
        <div>
          <h1>{getGreeting()}</h1>
          <p className="date">{formatDate(new Date())}</p>
        </div>
      </div>

      

      <div className="home-grid">
        <div className="home-widget">
          <h3><FaBullhorn /> Announcements</h3>
          <div className="home-scroll">
            {announcements.length > 0 ? (
              announcements.map((ann) => (
                <div key={ann.id} style={{ marginBottom: "10px", paddingBottom: "10px", borderBottom: "1px solid #e5e7eb" }}>
                  <p style={{ fontWeight: "600", margin: "0 0 5px 0", fontSize: "18px" }}>{ann.title}</p>
                  <p style={{ margin: "0 0 5px 0", fontSize: "16px" }}>{ann.message}</p>
                  <p style={{ margin: 0, fontSize: "14px", color: "#9ca3af" }}>
                    Posted: {formatDate(ann.created_at)}
                    {ann.expiry_date && ` • Expires: ${formatDate(ann.expiry_date)}`}
                  </p>
                </div>
              ))
            ) : (
              <p style={{ color: "#9ca3af" }}>No announcements</p>
            )}
          </div>
        </div>

        <div className="home-widget">
          <h3><FaCalendarCheck /> Upcoming Events</h3>
          <div className="home-scroll large">
            {upcomingEvents.length > 0 ? (
              upcomingEvents.map((event) => (
                <div key={event.id} style={{ marginBottom: "10px", paddingBottom: "10px", borderBottom: "1px solid #e5e7eb" }}>
                  <p style={{ fontWeight: "600", margin: "0 0 5px 0", fontSize: "18px" }}>
                    📅 {event.title}
                  </p>
                  <p style={{ margin: "0 0 5px 0", fontSize: "16px", color: "#6b7280" }}>
                    {formatDate(event.event_date)}
                    {event.department && ` • ${event.department}`}
                  </p>
                  {event.description && (
                    <p style={{ margin: 0, fontSize: "14px", color: "#9ca3af" }}>{event.description}</p>
                  )}
                </div>
              ))
            ) : (
              <p style={{ color: "#9ca3af" }}>No upcoming events</p>
            )}
          </div>
        </div>

        <div className="home-widget">
          <h3><FaBirthdayCake /> Today's Celebrations</h3>
          <div className="home-scroll large">
            {celebrations.length > 0 ? (
              celebrations.map((cel, i) => (
                <div key={i} style={{ marginBottom: "12px", padding: "12px", background: "#f9fafb", borderRadius: "8px", border: "1px solid #e5e7eb" }}>
                  <p style={{ margin: "0 0 4px 0", fontSize: "16px", fontWeight: "600", color: "#111827" }}>
                    {getCelebrationIcon(cel.type)} {cel.name}
                  </p>
                  <p style={{ margin: "0 0 4px 0", fontSize: "14px", color: "#6b7280" }}>
                    {cel.department || 'N/A'}
                  </p>
                  <p style={{ margin: 0, fontSize: "14px", color: "#0284c7", fontWeight: "500" }}>
                    {cel.type}{cel.years ? ` (${cel.years} years)` : ''}
                  </p>
                </div>
              ))
            ) : (
              <p style={{ color: "#9ca3af", textAlign: "center", padding: "20px" }}>No celebrations today</p>
            )}
          </div>
        </div>
      </div>

      <div className="home-grid-2">
        <div className="home-widget">
          <h3><FaDownload /> Downloads</h3>
          <div className="home-scroll large">
            {downloads.length > 0 ? (
              downloads.map((dl) => (
                <a 
                  key={dl.id} 
                  href={dl.file_url} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  style={{ 
                    marginBottom: "12px", 
                    display: "flex", 
                    alignItems: "center", 
                    gap: "10px", 
                    textDecoration: "none", 
                    color: "inherit", 
                    cursor: "pointer",
                    padding: "8px",
                    borderRadius: "6px"
                  }} 
                  className="hover-bg"
                >
                  <span style={{ fontSize: "20px" }}>
                    {dl.category === 'org chart' ? '📊' : 
                     dl.category === 'logo' ? '🖼️' : 
                     dl.category === 'template' ? '📝' : '📄'}
                  </span>
                  <div>
                    <p style={{ margin: 0, fontWeight: "500", color: "#0284c7" }}>{dl.name}</p>
                    <small style={{ color: "#6b7280" }}>
                      {dl.category} • {formatDate(dl.updated_date)}
                    </small>
                  </div>
                </a>
              ))
            ) : (
              <p style={{ color: "#9ca3af" }}>No downloads available</p>
            )}
          </div>
        </div>

        <div className="home-widget">
          <h3><FaFileAlt /> Policies</h3>
          <div className="home-scroll large">
            {policies.length > 0 ? (
              policies.map((pol) => (
                <a 
                  key={pol.id} 
                  href={pol.file_url} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  style={{ 
                    marginBottom: "10px", 
                    paddingBottom: "8px", 
                    borderBottom: "1px solid #f3f4f6", 
                    display: "block", 
                    textDecoration: "none",
                    padding: "8px",
                    borderRadius: "6px"
                  }} 
                  className="hover-bg"
                >
                  <p style={{ margin: "0 0 4px 0", fontWeight: "500", color: "#0284c7" }}>
                    {pol.name}
                  </p>
                  <small style={{ color: "#6b7280" }}>
                    Version: {pol.version}
                    {pol.category && ` • ${pol.category}`}
                  </small>
                  <br />
                  <small style={{ color: "#9ca3af" }}>
                    Updated: {formatDate(pol.updated_date)}
                  </small>
                </a>
              ))
            ) : (
              <p style={{ color: "#9ca3af" }}>No active policies</p>
            )}
          </div>
        </div>

        <div className="home-widget">
          <h3><FaCalendarCheck /> Holiday Calendar</h3>
          <div className="home-scroll large">
            {holidays.length > 0 ? (
              holidays.map((h) => (
                <div 
                  key={h.id} 
                  style={{ 
                    marginBottom: "10px", 
                    borderBottom: "1px solid #f3f4f6", 
                    paddingBottom: "8px" 
                  }}
                >
                  <p style={{ margin: "0 0 4px 0", fontWeight: "600", color: "#374151", fontSize: "16px" }}>
                    {formatDate(h.date)}
                  </p>
                  <p style={{ margin: 0, color: "#6b7280", fontSize: "14px" }}>
                    {h.name}
                  </p>
                  {h.description && (
                    <p style={{ margin: "4px 0 0 0", fontSize: "12px", color: "#9ca3af" }}>
                      {h.description}
                    </p>
                  )}
                </div>
              ))
            ) : (
              <p style={{ color: "#9ca3af" }}>No upcoming holidays</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
